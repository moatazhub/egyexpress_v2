<?php
/*
Plugin Name:  egyexpress Shipping WooCommerce
Plugin URI:   https://egyexpress.com
Description:  egyexpress Shipping WooCommerce plugin
Version:      1.0.0
Author:       egyexpress.com
Author URI:   https://www.egyexpress.com/solutions-services/developers-solutions-center
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  egyexpress
Domain Path:  /languages
*/

include_once __DIR__ . '../../core/class-egyexpress-helper.php';
include_once __DIR__ . '/class-egyexpress-woocommerce-serchautocities_model.php';

/**
 * Class egyexpress_Serchautocities_Method is a controller for Serchautocities functionality
 */
class egyexpress_Serchautocities_Method extends egyexpress_Helper
{
    /**
     * Model object
     * @var object egyexpress_Serchautocities_Method_Model
     */
    private $model;

    /**
     * egyexpress_Serchautocities_Method constructor
     */
    public function __construct()
    {
        $this->model = new egyexpress_Serchautocities_Method_Model();
    }

    /**
     * Starting method
     *
     * @return array Result from egyexpress server
     */
    public function run()
    {
        if (isset($_GET['backend'])) {
            check_ajax_referer('egyexpress-shipment-check' . wp_get_current_user()->user_email);
        } else {
            check_ajax_referer('serchautocities', 'security');
        }
        $get = $this->formatPost($_GET);
        $countryCode = $get['country_code'];
        $term = $get['term'];
        $cities = $this->model->fetchCities($countryCode, $term);
        if (count($cities) > 0 && $cities != false) {
            if (is_array($cities)) {
                $cities = array_unique($cities);
            } else {
                $cities_temp = $cities;
                $cities = array();
                $cities[] = $cities_temp;
            }
            $sortCities = array();
            foreach ($cities as $v) {
                $sortCities[] = ucwords(strtolower($v));
            }
            asort($sortCities, SORT_STRING);
            $to_return = array();
            foreach ($sortCities as $val) {
                $to_return[] = $val;
            }
            echo json_encode($to_return);
            die();
        } else {
            echo json_encode(array());
            die();
        }
    }
}