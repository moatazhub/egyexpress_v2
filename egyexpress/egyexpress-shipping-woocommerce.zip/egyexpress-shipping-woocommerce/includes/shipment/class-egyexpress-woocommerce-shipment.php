<?php
/*
Plugin Name:  egyexpress Shipping WooCommerce
Plugin URI:   https://egyexpress.com
Description:  egyexpress Shipping WooCommerce plugin
Version:      1.0.0
Author:       egyexpress.com
Author URI:   https://www.egyexpress.com/solutions-services/developers-solutions-center
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  egyexpress
Domain Path:  /languages
*/

include_once __DIR__ . '../../core/class-egyexpress-helper.php';

/**
 * Controller for Shipment functionality
 */
class egyexpress_Shipment_Method extends egyexpress_Helper
{
    /**
     * Starting method
     *
     * @return mixed|string
     */
    public function run()
    {
        check_admin_referer('egyexpress-shipment-check' . wp_get_current_user()->user_email);
        $post = $this->formatPost($_POST);

        if ($post['egyexpress_shipment_shipper_account_show'] == 1) {
            $info = $this->getInfo(wp_create_nonce('egyexpress-shipment-check' . wp_get_current_user()->user_email));
        } else {
            $info = $this->getInfoCod(wp_create_nonce('egyexpress-shipment-check' . wp_get_current_user()->user_email));
        }

       
        $egyexpress_errors = false;
        try {
            /* here's your form processing */
            $order = new WC_Order($post['egyexpress_shipment_original_reference']);
            $items = $order->get_items();
            $descriptionOfGoods = '';
            foreach ($items as $itemvv) {
                $descriptionOfGoods .= $itemvv['product_id'] . ' - ' . trim($itemvv['name'] . ' ');
            }
            $descriptionOfGoods = substr($descriptionOfGoods, 0, 65);
            $egyexpress_items_counter = 0;
            $totalItems = (trim($post['number_pieces']) == '') ? 1 : (int)$post['number_pieces'];
            $egyexpress_atachments = array();
            //attachment
            for ($i = 1; $i <= 3; $i++) {
                $fileName = $_FILES['file' . $i]['name'];
                if (isset($fileName) != '') {
                    $fileName = explode('.', $fileName);
                    $fileName = $fileName[0]; //filename without extension
                    $fileData = '';
                    if ($_FILES['file' . $i]['tmp_name'] != '') {
                        $fileData = file_get_contents($_FILES['file' . $i]['tmp_name']);
                    }
                    $ext = pathinfo($_FILES['file' . $i]['name'], PATHINFO_EXTENSION); //file extension
                    if ($fileName && $ext && $fileData) {
                        $egyexpress_atachments[] = array(
                            'FileName' => $fileName,
                            'FileExtension' => $ext,
                            'FileContents' => $fileData
                        );
                    }
                }
            }

            $totalWeight = $post['order_weight'];
            $params = array();
            
        
          
            if (!session_id()) {
                session_start();
            }
            $_SESSION['form_data'] = $post;

            /**
             * Used for tracking error messages
             *
             * @return mixed|strng
             */
            
            function egyexpress_errors()
            {
                static $wp_error; // Will hold global variable safely
                return isset($wp_error) ? $wp_error : ($wp_error = new WP_Error(null, null, null));
            }

            // prepare API post data
            $request_body['UserName'] =  $post['egyexpress_shipment_shipper_account_pin'];//"WEBSETest";//$options['userName'];
            $request_body['AccountNo'] = $post['egyexpress_shipment_shipper_account_number']; //"kZGy2o+Ve6s=";//$options['accountNo'];
            $request_body['Password'] =  $post['egyexpress_shipment_shipper_account_password'];//"FBFk9vOanXw=";//$options['password'];

            $request_body_sub['SendersPhone'] = $post['egyexpress_shipment_shipper_phone'];
            $request_body_sub['SendersCity'] = $post['egyexpress_shipment_shipper_state'];
            $request_body_sub['SendersAddress1'] = $post['egyexpress_shipment_shipper_street'];
            $request_body_sub['SendersAddress2'] = "";
            $request_body_sub['SendersContactPerson'] = $post['egyexpress_shipment_shipper_name'];
            $request_body_sub['SendersCompany'] = $post['egyexpress_shipment_shipper_company'];
            $request_body_sub['ReceiversCompany'] = $post['egyexpress_shipment_receiver_company'];
            $request_body_sub['ReceiversPhone'] = $post['egyexpress_shipment_receiver_phone'];
            $request_body_sub['ReceiversCity'] = $post['egyexpress_shipment_receiver_state'];
            $request_body_sub['ReceiversAddress1'] = $post['egyexpress_shipment_receiver_street'];
            $request_body_sub['ReceiversAddress2'] = "";
            $request_body_sub['CODAmount'] = $post['egyexpress_shipment_info_cod_amount'];
            $request_body_sub['NumberofPeices'] = $post['number_pieces'];
            $request_body_sub['Weight'] = $post['order_weight'];
            $request_body_sub['ShipmentDimension'] = "1";
            $request_body_sub['GoodsDescription'] = $post['egyexpress_shipment_description'];
            $request_body_sub['Origin'] = $post['egyexpress_shipment_shipper_state'];
            $request_body_sub['order_id'] = $post['egyexpress_shipment_original_reference'];
            $request_body_sub['ServiceType'] = "FRG";//$post['egyexpress_shipment_info_service_type'];//
            $request_body_sub['ProductType'] = "FRE"; //$post['egyexpress_shipment_info_product_type'];
            $request_body_sub['Destination'] = $post['egyexpress_shipment_receiver_state'];
            wc_get_logger()->info($post['egyexpress_shipment_info_service_type']);
            wc_get_logger()->info($post['egyexpress_shipment_info_product_type']);
            $request_body['AirwayBillData'] = $request_body_sub;


            try {
                //create shipment call

                $response = wp_remote_post("http://82.129.197.86:1929/EGEXPService.svc/CreateAirwayBill", array(
                    'headers'     => array('Content-Type' => 'application/json; charset=utf-8'),
                    'body'        => json_encode($request_body)));
                

                    if (is_wp_error($response)) {
                        $error_message = $response->get_error_message();
                        if ( isset( $error_message ) ) {
                            
                            egyexpress_errors()->add('error',
                                             __('egyexpress: ' . $error_message),
                                             'egyexpress');
                    
                        }

               
                    $_SESSION['egyexpress_errors'] = egyexpress_errors();
                    wp_redirect(sanitize_text_field(esc_url_raw($_SERVER["HTTP_REFERER"])) . '&egyexpresspopup/show');
                    exit;
                } else {

                    $body = json_decode(wp_remote_retrieve_body($response), true);
                    wc_get_logger()->info( $body['Code']);
                    wc_get_logger()->info( $body['Description']);
                    if ($post['egyexpress_return_shipment_creation_date'] == "create" && $body['Code'] == 1) {
                        $commentdata = array(
                            'comment_post_ID' => $post['egyexpress_shipment_original_reference'],
                            'comment_author' => '',
                            'comment_author_email' => '',
                            'comment_author_url' => '',
                            'comment_content' => "AWB No. " . $body['AirwayBillNumber'] . " - Order No. " . $post['egyexpress_shipment_original_reference'],
                            'comment_type' => 'order_note',
                            'user_id' => "0",
                        );
                        wp_new_comment($commentdata);
                        $order = new WC_Order($post['egyexpress_shipment_original_reference']);
                        $order->add_order_note($commentdata['comment_content']);
                        $order->save();
                        if (!empty($order)) {
                            $order->update_status('on-hold', __('egyexpress shipment created.', 'egyexpress'));
                        }

                        

                        egyexpress_errors()->add('success',
                            __('egyexpress Shipment Number: ',
                                'egyexpress') . $body['AirwayBillNumber'] . __(' has been created.',
                                'egyexpress'));

                      // return not create           
                    } elseif ($post['egyexpress_return_shipment_creation_date'] == "return") {
                        egyexpress_errors()->add('success',
                            __('egyexpress Shipment Return Order Number: ',
                                'egyexpress') . $body['AirwayBillNumber'] . __(' has been created.',
                                'egyexpress'));
                        $message = "egyexpress Shipment Return Order AWB No. " . $body['AirwayBillNumber'] . " - Order No. " . $post['egyexpress_shipment_original_reference'];
                        $commentdata = array(
                            'comment_post_ID' => $post['egyexpress_shipment_original_reference'],
                            'comment_author' => '',
                            'comment_author_email' => '',
                            'comment_author_url' => '',
                            'comment_content' => $message,
                            'comment_type' => 'order_note',
                            'user_id' => "0",
                        );
                        wp_new_comment($commentdata);
                    } else {
                        egyexpress_errors()->add('error', __('Cannot do shipment for the order. ', 'egyexpress') . $body['Description']);
                    }
                }
            } catch (Exception $e) {
                $egyexpress_errors = true;
                egyexpress_errors()->add('error', $e->getMessage());
            }

            if ($egyexpress_errors) {
                $_SESSION['egyexpress_errors'] = egyexpress_errors();
                wp_redirect(sanitize_text_field(esc_url_raw($_SERVER["HTTP_REFERER"])) . '&egyexpresspopup/show');
                exit;
            } else {
                //success exit
                $_SESSION['egyexpress_errors'] = egyexpress_errors();
                wp_redirect(sanitize_text_field(esc_url_raw($_SERVER["HTTP_REFERER"])) . '&egyexpresspopup/show');
                exit;
            }
        } catch (Exception $e) {
            $_SESSION['egyexpress_errors'] = egyexpress_errors();
            wp_redirect(sanitize_text_field(esc_url_raw($_SERVER["HTTP_REFERER"])) . '&egyexpresspopup/show');
            exit;
        }
    }
}
