<?php
/*
Plugin Name:  egyexpress Shipping WooCommerce
Plugin URI:   https://egyexpress.com
Description:  egyexpress Shipping WooCommerce plugin
Version:      1.0.0
Author:       egyexpress.com
Author URI:   https://www.egyexpress.com/solutions-services/developers-solutions-center
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  egyexpress
Domain Path:  /languages
*/
include_once __DIR__ . '../../core/class-egyexpress-helper.php';

/**
 * Controller for Printing label
 */
class egyexpress_Printlabel_Method extends egyexpress_Helper
{

    /**
     * Starting method
     *
     * @return mixed|string|void
     */
    public function run()
    {
        check_admin_referer('egyexpress-shipment-check' . wp_get_current_user()->user_email);
        $info = $this->getInfo(wp_create_nonce('egyexpress-shipment-check' . wp_get_current_user()->user_email));
        $post = $this->formatPost($_POST);

        if (!session_id()) {
            session_start();
        }
        if ($post['egyexpress_printlabel']) {
            //SOAP object
           // $soapClient = new SoapClient($info['baseUrl'] . 'shipping.wsdl', array('soap_version' => SOAP_1_1));
            $awbno = array();



            if ($post['egyexpress_lasttrack']) {
                $report_id = $info['clientInfo']['report_id'];
                if (!$report_id) {
                    $report_id = 9729;
                }
                $params = array(
                    'ClientInfo' => $info['clientInfo'],
                    'Transaction' => array(
                        'Reference1' => $post['egyexpress_printlabel'],
                        'Reference2' => '',
                        'Reference3' => '',
                        'Reference4' => '',
                        'Reference5' => '',
                    ),
                    'LabelInfo' => array(
                        'ReportID' => $report_id,
                        'ReportType' => 'URL',
                    ),
                );
                //$params['ShipmentNumber'] = $post['egyexpress_lasttrack'];

                // prepare API post data
                $request_body['UserName'] = $info['clientInfo']['AccountPin'];
                $request_body['AccountNo'] = $info['clientInfo']['AccountNumber'];
                $request_body['Password'] = $info['clientInfo']['Password'];
                $request_body['AirwayBillNumber'] = $post['egyexpress_lasttrack'];
                
                try {
                   // $auth_call = $soapClient->PrintLabel($params);
                    $response = wp_remote_post('http://82.129.197.86:1929/EGEXPService.svc/AirwayBillPDFFormat', array(
                        'headers'     => array('Content-Type' => 'application/json; charset=utf-8'),
                        'body'        => json_encode($request_body)));
           
                    $body = json_decode(wp_remote_retrieve_body($response), true); 
                    
                    if (is_wp_error($response)) {
                        $error_message = $response->get_error_message();
                        $this->egyexpress_errors()->add('error', $error_message);
                        $_SESSION['egyexpress_errors_printlabel'] = $this->egyexpress_errors();
                        wp_redirect(sanitize_text_field(esc_url_raw($_POST['egyexpress_shipment_referer'])) . '&egyexpresspopup/show_printlabel');
                        exit();
                    } 


                    /* bof  PDF demaged Fixes debug */
                    // if ($auth_call->HasErrors) {
                    //     if (count($auth_call->Notifications->Notification) > 1) {
                    //         foreach ($auth_call->Notifications->Notification as $notify_error) {
                    //             $error = "";
                    //             $error .= 'egyexpress: ' . $notify_error->Code . ' - ' . $notify_error->Message;
                    //             egyexpress_errors()->add('error', $error);
                    //         }
                    //     } else {
                    //         egyexpress_errors()->add('error',
                    //             'egyexpress: ' . $auth_call->Notifications->Notification->Code . ' - ' . $auth_call->Notifications->Notification->Message);
                    //     }
                    //     $_SESSION['egyexpress_errors'] = egyexpress_errors();
                    //     wp_redirect(sanitize_text_field(esc_url_raw($_POST['egyexpress_shipment_referer'])) . '&egyexpresspopup/show_printlabel');
                    //     exit();
                    // }
                    /* eof  PDF demaged Fixes */
                    $filepath = $body['ReportDoc']; //$auth_call->ShipmentLabel->LabelURL;
                    echo($filepath);
                    exit();
                } catch (Exception $e) {
                    $this->egyexpress_errors()->add('error', $e->getMessage());
                    $_SESSION['egyexpress_errors_printlabel'] = $this->egyexpress_errors();
                    wp_redirect(sanitize_text_field(esc_url_raw($_POST['egyexpress_shipment_referer'])) . '&egyexpresspopup/show_printlabel');
                    exit();
                }
            } else {
                $this->egyexpress_errors()->add('error', 'Shipment is empty or not created yet.');
                $_SESSION['egyexpress_errors_printlabel'] = $this->egyexpress_errors();
                wp_redirect(sanitize_text_field(esc_url_raw($_POST['egyexpress_shipment_referer'])) . '&egyexpresspopup/show_printlabel');
                exit();
            }
        } else {
            $this->egyexpress_errors()->add('error', 'This order no longer exists.');
            $_SESSION['egyexpress_errors_printlabel'] = $this->egyexpress_errors();
            wp_redirect(sanitize_text_field(esc_url_raw($_POST['egyexpress_shipment_referer'])) . '&egyexpresspopup/show_printlabel');
            exit();
        }
    }

    /**
     * Get errors
     *
     * @return WP_Error  WP Errors
     */
    public function egyexpress_errors()
    {
        static $wp_error; // Will hold global variable safely
        return isset($wp_error) ? $wp_error : ($wp_error = new WP_Error(null, null, null));
    }
}