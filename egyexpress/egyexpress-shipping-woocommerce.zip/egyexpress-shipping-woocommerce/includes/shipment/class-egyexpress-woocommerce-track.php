<?php
/*
Plugin Name:  egyexpress Shipping WooCommerce
Plugin URI:   https://egyexpress.com
Description:  egyexpress Shipping WooCommerce plugin
Version:      1.0.0
Author:       egyexpress.com
Author URI:   https://www.egyexpress.com/solutions-services/developers-solutions-center
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  egyexpress
Domain Path:  /languages
*/

include_once __DIR__ . '../../core/class-egyexpress-helper.php';

/**
 * Controller for Tracking functionality
 */
class egyexpress_Track_Method extends egyexpress_Helper
{
    /**
     * Starting method
     *
     * @return void
     */
    public function run()
    {
        check_admin_referer('egyexpress-shipment-check' . wp_get_current_user()->user_email);
        $info = $this->getInfo(wp_create_nonce('egyexpress-shipment-check' . wp_get_current_user()->user_email));
        $postArray = $this->formatPost($_POST);
        $post = $postArray['data'];
        $account = $info['clientInfo']['AccountNumber'];
        $trackingvalue = $post["egyexpress-track"];
        $response = array();

        //SOAP object
        // $soapClient = new SoapClient($info['baseUrl'] . 'Tracking.wsdl', array('soap_version' => SOAP_1_1));
        // $egyexpressParams = $this->_getAuthDetails($info);
        // $egyexpressParams['Transaction'] = array('Reference1' => '001');
        // $egyexpressParams['Shipments'] = array($trackingvalue);
        // $resegyexpress = $soapClient->TrackShipments($egyexpressParams);


        // prepare API post data
        $request_body['UserName'] = $info['clientInfo']['AccountPin'];
        $request_body['AccountNo'] = $info['clientInfo']['AccountNumber'];
        $request_body['Password'] = $info['clientInfo']['Password'];
        $request_body['TrackingAWB'] = $trackingvalue;

        $response_request = wp_remote_post('http://egyptexpress.me:1929/EGEXPService.svc/Tracking', array(
            'headers'     => array('Content-Type' => 'application/json; charset=utf-8'),
            'body'        => json_encode($request_body)));

        if(is_wp_error($response_request)){
            $response['type'] = 'error';
           
            $response['html'] .= '<b>' .$response_request->get_error_message() . '</b>' ;
        }
       

        $body = json_decode(wp_remote_retrieve_body($response_request), true);
        

        if (isset($body["Code"]) ) {

            
            if ($body["Code"] == 1) {
                $response['type'] = 'success';  
                $response['html'] = $this->getTrackingInfoTable($body["AirwayBillTrackList"][0]["TrackingLogDetails"]);
            } else {
                $response['html'] = __('Unable to retrieve quotes, please check if the Tracking Number is valid or contact your administrator.',
                    'egyexpress');
            }
        } else {
            $response['type'] = 'error';
            foreach ($resegyexpress->Notifications as $notification) {
                $response['html'] .= '<b>' . $notification->Code . '</b>' . $notification->Message;
            }
        }
        print json_encode($response);
        die();
    }

    /**
     * Get Client info from array
     * 
     * @param $info array Client info
     * @return array Client info
     */
    private function _getAuthDetails($info)
    {
        return array(
            'ClientInfo' => $info['clientInfo']
        );
    }

    /**
     * Creates HTML code for tracking table
     *
     * @param $HAWBHistory array
     * @return string
     */
    private function getTrackingInfoTable($HAWBHistory)
    {
        $checkArray = is_array($HAWBHistory);
        $resultTable = '<table summary="Item Tracking"  class="data-table">';
        $resultTable .= "<col width='1'>
                          <col width='1'>
                          <col width='1'>
                          <col width='1'>
                          <col width='1'>
                          <col width='1'>
                          <thead>
                          <tr class='first last'>
                          <th>" . __('Activity Date', 'egyexpress') . "</th>
                          <th>" . __('Activity Time', 'egyexpress') . "</th>
                          <th class='a-right'>" . __('DeliveredTo', 'egyexpress') . "</th>
                          <th class='a-center'>" . __('Location', 'egyexpress') . "</th>
                          <th class='a-center'>" . __('Remarks', 'egyexpress') . "</th>
                          <th class='a-center'>" . __('Status', 'egyexpress') . "</th>
                          </tr>
                          </thead><tbody>";
        if ($checkArray) {
            foreach ($HAWBHistory as $HAWBUpdate) {
                $resultTable .= '<tr>
                    <td>' . $HAWBUpdate["ActivityDate"]  .'</td>
                    <td>' . $HAWBUpdate["ActivityTime"] . '</td>
                    <td>' . $HAWBUpdate["DeliveredTo"] . '</td>
                    <td>' . $HAWBUpdate["Location"] . '</td>
                    <td>' . $HAWBUpdate["Remarks"] . '</td>
                    <td>' . $HAWBUpdate["Status"] . '</td>
                    </tr>';
            }
        } else {
            $resultTable .= '<tr>
            <td>' . $HAWBHistory["ActivityDate"]  .'</td>
            <td>' . $HAWBHistory["ActivityTime"] . '</td>
            <td>' . $HAWBHistory["DeliveredTo"] . '</td>
            <td>' . $HAWBHistory["Location"] . '</td>
            <td>' . $HAWBHistory["Remarks"] . '</td>
            <td>' . $HAWBHistory["Status"] . '</td>
                    </tr>';
        }
        $resultTable .= '</tbody></table>';
        return $resultTable;
    }
}
