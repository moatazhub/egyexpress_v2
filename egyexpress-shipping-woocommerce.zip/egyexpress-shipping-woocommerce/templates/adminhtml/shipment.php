<?php
/*
Plugin Name:  egyexpress Shipping WooCommerce
Plugin URI:   https://egyexpress.com
Description:  egyexpress Shipping WooCommerce plugin
Version:      1.0.0
Author:       egyexpress.com
Author URI:   https://www.egyexpress.com/solutions-services/developers-solutions-center
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  egyexpress
Domain Path:  /languages
*/
?>
<?php
        /**
         *  Render "Shipment" form
         *
         * @param $order object Order object
         * @return string Template
         */
function egyexpress_display_order_data_in_admin($order)
{
    $get_userdata = get_userdata(get_current_user_id());
    if (!$get_userdata->allcaps['edit_shop_order'] || !$get_userdata->allcaps['read_shop_order'] || !$get_userdata->allcaps['edit_shop_orders'] || !$get_userdata->allcaps['edit_others_shop_orders']
        || !$get_userdata->allcaps['publish_shop_orders'] || !$get_userdata->allcaps['read_private_shop_orders']
        || !$get_userdata->allcaps['edit_private_shop_orders'] || !$get_userdata->allcaps['edit_published_shop_orders']
    ) {
        return false;
    }

    $order_id = $order->get_id();
    remove_filter('comments_clauses', array('WC_Comments', 'exclude_order_comments'));

    $history = get_comments(array(
        'post_id' => $order_id,
        'orderby' => 'comment_ID',
        'order' => 'DESC',
        'approve' => 'approve',
        'type' => 'order_note',
    ));
    add_filter('comments_clauses', array('WC_Comments', 'exclude_order_comments'));

    $history_list = array();
    foreach ($history as $shipment) {
        $history_list[] = $shipment->comment_content;
    }

    $shipped = false;
    if (count($history_list)) {
        foreach ($history_list as $val) {
            if (strpos($val, "- Order No") !== false) {
                $shipped = true;
                break;
            }
        }
    }
    $egyexpress_return_button = false;

    if (count($history_list)) {
        foreach ($history_list as $history) {
            $pos = strpos($history, 'Return');
            if ($pos) {
                $egyexpress_return_button = true;
                break;
            }
            $awbno = strstr($history, "- Order No", true);
            $awbno = trim($awbno, "AWB No.");
            if ($awbno != "") {
                $egyexpress_return_button = true;
                break;
            }
        }
    } ?>
<!-- egyexpress shipment -->
    <div style="clear:both; padding-top:10px;">
        <a class=' button-primary ' style="margin-top:15px; margin-left:15px; display:none; "
           id="create_egyexpress_shipment"><?php echo esc_html__('Prepare Egypt Express Shipment', 'egyexpress'); ?> </a>
        <?php if ($shipped === true) {
        ?>
            <a class=' button-primary ' style="margin-top:15px; margin-left:15px; display:none;"
               id="track_egyexpress_shipment"><?php echo esc_html__('Track egyexpress Shipment', 'egyexpress'); ?> </a>
        <?php 
    } ?>
        <?php if ($egyexpress_return_button === true) {
        ?>
            <a class='button-primary' style="margin-top:15px; margin-left:15px; display:none;"
               id="print_egyexpress_shipment" ><?php echo esc_html__('Print Label', 'egyexpress'); ?> </a>
        <?php 
    } ?>
    </div>

    <?php
    if (!session_id()) {
        session_start();
    }
    $session = false;
    if (isset($_SESSION['form_data'])) {
        $session = true;
    }

    $countryCollection = WC()->countries->countries;
    //calculating total weight of current order
    $totalWeight = 0;
    $weight = 0;
    $itemsv = $order->get_items();
    foreach ($itemsv as $itemvv) {
        if ($itemvv['product_id'] > 0) {
            $product = $order->get_product_from_item($itemvv);
            if (!$product->is_virtual()) {
                $productData =  $product->get_data();
                if( $product->is_type( 'simple' ) ){
                    // a simple product
                    $weight = $productData['weight'];
                  } elseif( $product->is_type( 'variation' ) || $product->is_type( 'variable' ) ){
                    // a variable product
                    if(empty($productData['weight'])){
                        if(wc_get_product($product->get_parent_id())){
                            $parent_weight = $product->get_parent_data();
                            $weight =  $parent_weight['weight'];
                        }
                    }else{
                        $weight = $productData['weight'];
                    }
                  }
                $totalWeight += (float)$weight * $itemvv['qty'];
            }
        }
    }
    
    include_once(plugin_dir_path(__FILE__) . '../../includes/shipping/class-egyexpress-woocommerce-shipping.php');
    include_once(plugin_dir_path(__FILE__) . '../../includes/core/class-egyexpress-helper.php');
    $settings = new egyexpress_Shipping_Method();
    $helper = new egyexpress_Helper();

    $stateCollection = WC()->countries->get_states('EG'); // States array for a country
    $account = $settings->settings['account_number'];
    $account_pin = $settings->settings['account_pin']; // Username
    $account_password = $settings->settings['password'];
    $account_number = $settings->settings['account_number'];
   // $cod_account_number = $settings->settings['cod_account_number'];
   // $cod_account_pin = $settings->settings['cod_account_pin'];
    $name = $settings->settings['name'];
    $email = $settings->settings['email_origin'];
    $company = $settings->settings['company'];
    $address = $settings->settings['address'];
    $country = $settings->settings['country'];
    $city = $settings->settings['city'];
    $postalcode = $settings->settings['postalcode'];
    $state = $settings->settings['state'];
    $shipperStates = $helper->Mylrez();
    

    $phone = $settings->settings['phone'];
    $currentUrl = home_url(add_query_arg(null, null));
    $allowed_domestic_methods_all = $settings->form_fields['allowed_domestic_methods']['options'];
    $allowed_domestic_methods = array();
    // foreach ($settings->settings['allowed_domestic_methods'] as $domestic_method) {
    //     $allowed_domestic_methods[$domestic_method] = $allowed_domestic_methods_all[$domestic_method];
    // }
    $allowed_international_methods_all = $settings->form_fields['allowed_international_methods']['options'];
    $allowed_international_methods = array();
    // foreach ($settings->settings['allowed_international_methods'] as $international_method) {
    //     $allowed_international_methods[$international_method] = $allowed_international_methods_all[$international_method];
    // }
    $allowed_domestic_additional_services = $settings->form_fields['allowed_domestic_additional_services']['options'];
    $allowed_international_additional_services = $settings->form_fields['allowed_international_additional_services']['options'];
   // $allowed_cod = $settings->settings['allowed_cod'];
    $unit = get_option('woocommerce_weight_unit');
    $dom = $settings->settings['allowed_domestic_methods'];
    $exp = $settings->settings['allowed_international_methods'];
    $phone_reciver = "";
    $email_reciver = "";
    $data = $order->get_data();
    foreach ($data['meta_data'] as $item) {
        if ($item->key == "_shipping_phone") {
            $phone_reciver = $item->value;
        }
        if ($item->key == "_shipping_email") {
            $email_reciver = $item->value;
        }
    }
    $phone_reciver = isset($phone_reciver) ? $phone_reciver : $order->billing_phone;
    $email_reciver = isset($email_reciver) ? $email_reciver : $order->billing_email;
    $payment_method = $data['payment_method'];
    $payment_method_title = $data['payment_method_title']; ?>

    <script>
        jQuery.noConflict();
        (function ($) {
            myObj = {
                printLabelUrl: '',
                wh: $(window).height(),
                ww: $(window).width(),
                shipperCountry: '',
                shipperCity: '',
                shipperZip: '',
                shipperState: '',
                recieverCountry: '',
                recieverCity: '',
                recieverZip: '',
                recieverState: '',
                openWindow: function (param1, param2) {
                    $(param1).css({'visibility': 'hidden', 'display': 'block'});

                    var h = $(param2).height();
                    var w = $(param2).width();
                    var wh = this.wh;
                    var ww = this.ww;
                    if (h >= wh) {
                        h = wh - 20;
                        $(param2).css({'height': (h - 30)});
                    } else {
                        h = h + 30;
                    }

                    var t = wh - h;
                    t = t / 2;
                    var l = ww - w
                    l = l / 2;
                    $('.back-over').fadeIn(200);
                    $(param1).css({
                        'visibility': 'visible',
                        'display': 'none',
                        'height': 'auto',
                        'top': 30 + 'px'
                    }).fadeIn(500);

                },
                openCalc: function () {
                    this.cropValues();
                    this.openWindow('.cal-rate-part', '.cal-form');
                },
                defaultVal: function () {
                    this.shipperCountry = $('egyexpress_shipment_shipper_country').value;
                    this.shipperCity = $('egyexpress_shipment_shipper_city').value;
                    this.shipperZip = $('egyexpress_shipment_shipper_postal').value;
                    this.shipperState = $('egyexpress_shipment_shipper_state').value;

                    this.recieverCountry = $('egyexpress_shipment_receiver_country').value;
                    this.recieverCity = $('egyexpress_shipment_receiver_city').value;
                    this.recieverZip = $('egyexpress_shipment_receiver_postal').value;
                    this.recieverState = $('egyexpress_shipment_receiver_state').value;
                },
                cropValues: function () {
                    this.defaultVal();
                    var orginCountry = this.getId('origin_country');
                    this.setSelectedValue(orginCountry, this.shipperCountry);
                    $('origin_city').value = this.shipperCity;
                    $('origin_zipcode').value = this.shipperZip;
                    $('origin_state').value = this.shipperState;

                    var desCountry = this.getId('destination_country');
                    this.setSelectedValue(desCountry, this.recieverCountry);
                    $('destination_city').value = this.recieverCity;
                    $('destination_zipcode').value = this.recieverZip;
                    $('destination_state').value = this.recieverState;
                },
                getId: function (id) {
                    return document.getElementById(id);
                },
                setSelectedValue: function (selectObj, valueToSet) {
                    for (var i = 0; i < selectObj.options.length; i++) {
                        if (selectObj.options[i].value == valueToSet) {
                            selectObj.options[i].selected = true;
                            return;
                        }
                    }
                },
                openPickup: function () {
                    this.defaultVal();
                    var pickupCountry = this.getId('pickup_country');
                    this.setSelectedValue(pickupCountry, this.shipperCountry);
                    $('pickup_city').value = this.shipperCity;
                    $('pickup_zip').value = this.shipperZip;
                    $('pickup_state').value = this.shipperState;
                    $('pickup_address').value = $('egyexpress_shipment_shipper_street').value;
                    $('pickup_company').value = $('egyexpress_shipment_shipper_company').value;
                    $('pickup_contact').value = $('egyexpress_shipment_shipper_name').value;
                    $('pickup_email').value = $('egyexpress_shipment_shipper_email').value;
                    this.openWindow('.schedule-pickup-part', '.pickup-form');
                },
                close: function () {
                    $('.back-over').fadeOut(500);
                    $('.cal-rate-part, .schedule-pickup-part').fadeOut(200);
                    $('.rate-result').css('display', 'none');
                    $('.pickup-result').css('display', 'none');
                },
                calcRate: function () {
                    $('.egyexpress_loader').css('display', 'block');
                    $('.rate-result').css('display', 'none');

                  var currentForm = $("#calc-rate-form").serializeArray();
                  var currentFormObject = {};
                  $.each(currentForm,
            function(i, v) {
                currentFormObject[v.name] = v.value;
            });
            var postData = {
			action: 'the_egyexpress_rate_calculator',
			data:currentFormObject,
            _wpnonce :  currentFormObject['_wpnonce']

		};
               
		jQuery.post(ajaxurl, postData, function(request) {
        var json = jQuery.parseJSON(request);
		if (json.type == 'success') {
            $(".result").html(json.html);
            $('.egyexpress_loader').css('display', 'none');
        } else {
            var error = "<div class='error'>" + json.error + "</div>";
             $(".result").html(error);
             $('.egyexpress_loader').css('display', 'none');
            }
         $(".rate-result").show();
		});
                   
                },
                track: function () {
                    
                    $('.egyexpress_loader').css('display', 'block');
                    $('.track-result').css('display', "none");
                    var currentForm = $("#track-form").serializeArray();
                    var currentFormObject = {};
                    $.each(currentForm,
                    function(i, v) {
                        currentFormObject[v.name] = v.value;
                    });
                      
            var postData = {
			action: 'the_egyexpress_track',
			data:currentFormObject,
            _wpnonce :  currentFormObject['_wpnonce']

		};
               
		jQuery.post(ajaxurl, postData, function(request) {
        var json = jQuery.parseJSON(request);
                            if (json.type == 'success') {
                                $(".result").html(json.html);
                                $('.egyexpress_loader').css('display', 'none');
                            } else {
                                var error = "<div class='error'>" + json.error + "</div>";
                                $(".result").html(error);
                                $('.egyexpress_loader').css('display', 'none');
                            }
                            $(".track-result").show();                       
        });
                       
                },
                schedulePickup: function () {
                    $('.pickup-result').css('display', 'none');
                    $('.egyexpress_loader').css('display', 'block');
                    var currentForm = $("#pickup-form").serializeArray();
                    var currentFormObject = {};
                    $.each(currentForm,
                    function(i, v) {
                        currentFormObject[v.name] = v.value;
                    });
                      
            var postData = {
			action: 'the_egyexpress_pickup',
			data : currentFormObject,
            _wpnonce :  currentFormObject['_wpnonce']

		};
               
		jQuery.post(ajaxurl, postData, function(request) {
        var json = jQuery.parseJSON(request);
                            if (json.type == 'success') {
                                $(".pickup-res").html(json.html);
                                $('.egyexpress_loader').css('display', 'none');
                            } else {
                                var error = "<div class='error'>" + json.error + "</div>";
                                $(".pickup-res").html(error);
                                $('.egyexpress_loader').css('display', 'none');
                            }
                            $(".pickup-result").show();                    
        });                    
                },
                ajax: function (formId, result1, result2) {
                }
            }
        })(jQuery);
    </script>

    <form></form>
    <div id="egyexpress_overlay">
        <div id="egyexpress_shipment_creation">
            <?php

            if (isset($_SESSION['egyexpress_errors']) && $_SESSION['egyexpress_errors']->errors > 0) {
                echo '<div class="egyexpress_errors">';
                // Loop error codes and display errors
                foreach ($_SESSION['egyexpress_errors']->errors as $key => $error) {
                    if ($key == "error") {
                        foreach ($error as $value) {
                            echo '<span class="error">' . esc_html($value) . '</span><br/>';
                        }
                    } else {
                        foreach ($error as $value) {
                            echo '<span class="success">' . esc_html($value) . '</span><br/>';
                        }
                    }
                }
                echo '</div>';
            } ?>
            <form id="egyexpress_shipment" method="post"
                  action="<?php echo esc_url(admin_url('admin-post.php')); ?>"
                  enctype="multipart/form-data">
                <input type="hidden" name="action" value="the_egyexpress_shipment"/>
                <input type="hidden" name="egyexpress_shipment_referer" value="<?php echo esc_attr($currentUrl) ?>"/>
                <input name="_wpnonce" id="egyexpress-shipment-nonce" type="hidden"
                       value="<?php echo esc_attr(wp_create_nonce('egyexpress-shipment-check' . wp_get_current_user()->user_email)); ?>"/>
                <input name="egyexpress_shipment_shipper_account" type="hidden" value="<?php echo esc_attr($account); ?>"/>
                <input name="egyexpress_shipment_shipper_account_pin" type="hidden" value="<?php echo esc_attr($account_pin); ?>"/>
                <input name="egyexpress_shipment_shipper_account_cod" type="hidden" value="<?php echo esc_attr($cod_account_number); ?>"/>
                <input name="egyexpress_shipment_shipper_account_pin_cod" type="hidden" value="<?php echo esc_attr($cod_account_pin); ?>"/> 
                <input name="egyexpress_shipment_shipper_account_password" type="hidden" value="<?php echo esc_attr($account_password); ?>"/>
                <input name="egyexpress_shipment_shipper_account_number" type="hidden" value="<?php echo esc_attr($account_number); ?>"/>
                
                <input name="egyexpress_shipment_original_reference" type="hidden"
                       value="<?php echo esc_attr($order_id); ?>"/>
                <FIELDSET class="egyexpress_shipment_creation_fieldset_big" id="egyexpress_shipment_creation_general_info">
                   
                    <div id="general_details" class="egyexpress_shipment_creation_part">
                        
                       
                        
                        <div class="cal-rate-button" style="float:right;">
                           
                            <?php if ($egyexpress_return_button === true) {
                                        ?>
                                    <a class='button-primary print_egyexpress_shipment' 
                                       id="print_egyexpress_shipment"><?php echo esc_html__('Print Label', 'egyexpress'); ?> </a>
                                <?php 
                                    } ?>
                        </div>
                </FIELDSET>
                <div id="egyexpress_messages"></div>
                <!--  Shipper DetailsShipper Details -->
                <FIELDSET class="egyexpress_shipment_creation_fieldset egyexpress_shipment_creation_fieldset_left">
                    <legend><?php echo esc_html__('Shipper Details', 'egyexpress'); ?></legend>
                    <div id="shipper_details" class="egyexpress_shipment_creation_part">
                        <div class="text_short">
                            <label><?php echo esc_html__('Reference', 'egyexpress'); ?></label><input class="number"
                                                                                                  type="text"
                                                                                                  name="egyexpress_shipment_shipper_reference"
                                                                                                  value="<?php echo esc_attr($order_id) ?>"/>
                        </div>
                        <div class="text_short">
                            <?php $name1 = ($session) ? $_SESSION['form_data']['egyexpress_shipment_shipper_name'] : $name; ?>
                            <label><?php echo esc_html__('Name', 'egyexpress'); ?> <span class="red">*</span></label><input
                                    type="text" class="required"
                                    id="egyexpress_shipment_shipper_name"
                                    name="egyexpress_shipment_shipper_name"
                                    value="<?php echo esc_attr($name1); ?>"/>
                        </div>
                        <div class="text_short">
                            <?php $email1 = ($session) ? $_SESSION['form_data']['egyexpress_shipment_shipper_email'] : $email; ?>
                            <label><?php echo esc_html__('Email', 'egyexpress'); ?> <span class="red">*</span></label><input
                                    type="text" class="required email"
                                    id="egyexpress_shipment_shipper_email"
                                    name="egyexpress_shipment_shipper_email"
                                    value="<?php echo esc_attr($email1); ?>"/>
                        </div>
                        <div class="text_short">
                            <?php $company1 = ($session) ? $_SESSION['form_data']['egyexpress_shipment_shipper_company'] : $company; ?>
                            <label><?php echo esc_html__('Company', 'egyexpress'); ?></label><input type="text"
                                                                                                id="egyexpress_shipment_shipper_company"
                                                                                                name="egyexpress_shipment_shipper_company"
                                                                                                value="<?php echo esc_attr($company1); ?>"/>
                        </div>
                        <div class="text_short">
                            <?php $street1 = ($session) ? $_SESSION['form_data']['egyexpress_shipment_shipper_street'] : $address; ?>
                            <label><?php echo esc_html__('Address', 'egyexpress'); ?> <span
                                        class="red">*</span></label><textarea rows="4" class="required"
                                                                              cols="26" type="text"
                                                                              id="egyexpress_shipment_shipper_street"
                                                                              name="egyexpress_shipment_shipper_street"><?php echo esc_textarea($street1); ?></textarea>
                        </div>
                        <div class="text_short">
                        <?php $country1 = ($session) ? $_SESSION['form_data']['egyexpress_shipment_shipper_country'] : $country; ?>
                            <label><?php echo esc_html__('Country', 'egyexpress'); ?> <span
                                        class="red no-display">*</span></label><input class="egyexpress_country"
                                                                                      autocomplete="off"
                                                                                      type="text"
                                                                                      id="egyexpress_shipment_shipper_country"
                                                                                      name="egyexpress_shipment_shipper_country"
                                                                                      value="<?php echo esc_attr($country1); ?>"/>

                        </div>
                        <div class="text_short">
                            <?php $city1 = ($session) ? $_SESSION['form_data']['egyexpress_shipment_shipper_city'] : $city; ?>
                            <label><?php echo esc_html__('City', 'egyexpress'); ?> <span
                                        class="red no-display">*</span></label><input class="egyexpress_city"
                                                                                      autocomplete="off"
                                                                                      type="text"
                                                                                      id="egyexpress_shipment_shipper_city"
                                                                                      name="egyexpress_shipment_shipper_city"
                                                                                      value="<?php echo esc_attr($city1); ?>"/>

                        </div>
                        <div class="text_short">
                            <?php $postalcode1 = ($session) ? $_SESSION['form_data']['egyexpress_shipment_shipper_postal'] : $postalcode; ?>
                            <label><?php echo esc_html__('Postal Code', 'egyexpress'); ?> <span
                                        class="red no-display">*</span></label><input class="" type="text"
                                                                                      id="egyexpress_shipment_shipper_postal"
                                                                                      name="egyexpress_shipment_shipper_postal"
                                                                                      value="<?php echo esc_attr($postalcode1); ?>"/>
                        </div>
                        <div class="text_short">
                            <label><?php echo esc_html__('State', 'egyexpress'); ?> <span class="red">*</span></label>
                            <select class="egyexpress_states validate-select" id="egyexpress_shipment_shipper_state"
                                    name="egyexpress_shipment_shipper_state">
                                    <?php $state1 = ($session) ? $_SESSION['form_data']['egyexpress_shipment_shipper_state'] : $state; ?>
                                <?php foreach ($shipperStates as $key => $value) {
                                        ?>
                                    <option value="<?php echo esc_attr($key) ?>" <?php
                                    if ($state1) {
                                        echo ($state1 == $key) ? 'selected="selected"' : '';
                                    } ?> ><?php echo esc_html($value) ?></option>
                                <?php 
                                    } ?>
                            </select>
                        </div>
                        <div class="text_short">
                            <?php $phone1 = ($session) ? $_SESSION['form_data']['egyexpress_shipment_shipper_phone'] : $phone; ?>
                            <label><?php echo esc_html__('Phone', 'egyexpress'); ?></label><input
                                    class="required" type="text" id="egyexpress_shipment_shipper_phone"
                                    name="egyexpress_shipment_shipper_phone" value="<?php echo esc_attr($phone1); ?>"/>
                        </div>
                    </div>
                </FIELDSET>
                <!--  Receiver Details -->
                <FIELDSET class="egyexpress_shipment_creation_fieldset egyexpress_shipment_creation_fieldset_right">
                    <legend><?php echo esc_html__('Receiver Details', 'egyexpress'); ?></legend>

                    <div class="text_short">
                        <label><?php echo esc_html__('Reference', 'egyexpress'); ?></label><input class="number" type="text"
                                                                                              id="egyexpress_shipment_receiver_reference"
                                                                                              name="egyexpress_shipment_receiver_reference"
                                                                                              value="<?php echo esc_attr($order_id); ?>"/>
                    </div>
                    <div class="text_short">
                        <?php
                        $name1 = ($order->get_shipping_first_name()) ? $order->get_shipping_first_name() : '';
    $name_last1 = ($order->get_shipping_last_name()) ? $order->get_shipping_last_name() : '';
    $name1 = $name1 . " " . $name_last1; ?>
                        <?php $name1 = ($session) ? $_SESSION['form_data']['egyexpress_shipment_receiver_name'] : $name1; ?>
                        <label><?php echo esc_html__('Name', 'egyexpress'); ?>
                            <span class="red">*</span></label><input class="required" type="text"
                                                                     id="egyexpress_shipment_receiver_name"
                                                                     name="egyexpress_shipment_receiver_name"
                                                                     value="<?php echo esc_attr($name1); ?>"/>
                    </div>
                    <div class="text_short">
                        <?php $email_reciver = ($order->get_billing_email()) ? $order->get_billing_email() : ''; ?>
                        <?php $email_reciver1 = ($session) ? $_SESSION['form_data']['egyexpress_shipment_receiver_email'] : $email_reciver; ?>
                        <label><?php echo esc_html__('Email', 'egyexpress'); ?> <span class="red">*</span></label><input
                                class="email required" type="text"
                                id="egyexpress_shipment_receiver_email"
                                name="egyexpress_shipment_receiver_email"
                                value="<?php echo esc_attr($email_reciver1); ?>"/>
                    </div>
                    <div class="text_short">
                        <?php $company_name = ($order->get_shipping_company()) ? $order->get_shipping_company() : ''; ?>
                        <?php $company_name = (empty($company_name)) ? $order->get_shipping_first_name() . " " . $order->get_shipping_last_name() : $company_name; ?>
                        <?php $company_name = ($session) ? $_SESSION['form_data']['egyexpress_shipment_receiver_company'] : $company_name; ?>

                        <label><?php echo esc_html__('Company', 'egyexpress'); ?></label><input type="text"
                                                                                            id="egyexpress_shipment_receiver_company"
                                                                                            name="egyexpress_shipment_receiver_company"
                                                                                            value="<?php echo esc_attr($company_name) ?>"/>
                    </div>
                    <div class="text_short">
                        <?php $street = ($order->get_shipping_address_1()) ? $order->get_shipping_address_1() : ''; ?>
                        <?php $street2 = ($order->get_shipping_address_2()) ? $order->get_shipping_address_2() : ''; ?>
                        <?php $street = $street . " " . $street2; ?>
                        <?php $street = ($session) ? $_SESSION['form_data']['egyexpress_shipment_receiver_street'] : $street; ?>
                        <label><?php echo esc_html__('Address', 'egyexpress'); ?> <span
                                    class="red">*</span></label><textarea class="required" rows="4"
                                                                          cols="26" type="text"
                                                                          id="egyexpress_shipment_receiver_street"
                                                                          name="egyexpress_shipment_receiver_street"><?php echo esc_attr($street); ?></textarea>
                    </div>
                    <div class="text_short">
                        <label><?php echo esc_html__('Country', 'egyexpress'); ?> <span class="red">*</span></label>
                        <?php $country1 = ($order->get_shipping_country()) ? $order->get_shipping_country() : ''; ?>
                        <?php $country1 = ($session) ? $_SESSION['form_data']['egyexpress_shipment_receiver_country'] : $country1; ?>
                        <select class="egyexpress_countries" id="egyexpress_shipment_receiver_country"
                                name="egyexpress_shipment_receiver_country">
                            <?php
                            foreach ($countryCollection as $key => $value) {
                                ?>
                                <option
                                        value="<?php echo $key ?>" <?php echo ($country1 == $key) ? 'selected="selected"' : ''; ?> ><?php echo esc_html($value); ?></option>
                                <?php

                            } ?>
                        </select>
                    </div>
                    <div class="text_short">
                        <?php $city1 = ($order->get_shipping_city()) ? $order->get_shipping_city(): ''; ?>
                        <?php $city1 = ($session) ? $_SESSION['form_data']['egyexpress_shipment_receiver_city'] : $city1; ?>
                        <label><?php echo esc_html__('City', 'egyexpress'); ?>
                            <span class="red no-display">*</span></label><input class="egyexpress_city" autocomplete="off"
                                                                                type="text"
                                                                                id="egyexpress_shipment_receiver_city"
                                                                                name="egyexpress_shipment_receiver_city"
                                                                                value="<?php echo $city1; ?>"/>
                        <div id="egyexpress_shipment_receiver_city_autocomplete" class="am_autocomplete"></div>
                    </div>
                    <div class="text_short">
                        <?php $postcode1 = ($order->get_shipping_postcode()) ? $order->get_shipping_postcode() : ''; ?>
                        <?php $postcode1 = ($session) ? $_SESSION['form_data']['egyexpress_shipment_receiver_postal'] : $postcode1; ?>
                        <label><?php echo esc_html__('Postal Code', 'egyexpress'); ?> <span class="red no-display">*</span></label><input
                                type="text" class=""
                                id="egyexpress_shipment_receiver_postal"
                                name="egyexpress_shipment_receiver_postal"
                                value="<?php echo esc_attr($postcode1); ?>"/>
                    </div>
                    <div class="text_short">
                            <label><?php echo esc_html__('State', 'egyexpress'); ?> <span class="red">*</span></label>
                            <select class="egyexpress_states validate-select" id="egyexpress_shipment_receiver_state"
                                    name="egyexpress_shipment_receiver_state">
                                    <?php $state1 = ($order->get_shipping_state()) ? $order->get_shipping_state() : ''; ?>
                                    <?php $state1 = ($session) ? $_SESSION['form_data']['egyexpress_shipment_receiver_state'] : $state1; ?>
                                <?php foreach ($stateCollection as $key => $value) {
                                        ?>
                                    <option value="<?php echo esc_attr($key) ?>" <?php
                                    if ($state1) {
                                        echo ($state1 == $key) ? 'selected="selected"' : '';
                                    } ?> ><?php echo esc_html($value) ?></option>
                                <?php 
                                    } ?>
                            </select>
                        </div>
                    <div class="text_short">
                        <?php $phone_reciver1 = ($order->get_billing_phone()) ? $order->get_billing_phone() : ''; ?>
                        <?php $phone_reciver1 = ($session) ? $_SESSION['form_data']['egyexpress_shipment_receiver_phone'] : $phone_reciver1; ?>
                        <label><?php echo esc_html__('Phone', 'egyexpress'); ?></label><input class="required" type="text"
                                                                                          id="egyexpress_shipment_receiver_phone"
                                                                                          name="egyexpress_shipment_receiver_phone"
                                                                                          value="<?php echo esc_attr($phone_reciver1); ?>"/>
                    </div>
                </FIELDSET>

                <!-- Shipment Information -->
                <div class="egyexpress_clearer"></div>
                <FIELDSET class="egyexpress_shipment_creation_fieldset_big">
                    <legend><?php echo esc_html__('Shipment Information', 'egyexpress'); ?></legend>
                    <div id="shipment_infromation" class="egyexpress_shipment_creation_part">
                        <div class="text_short">
                            <label><?php echo esc_html__('Total weight:', 'egyexpress'); ?></label>
                            <?php $totalWeight = ($session) ? $_SESSION['form_data']['order_weight'] : $totalWeight; ?>
                            <input type="text" name="order_weight" value="<?php echo esc_attr($totalWeight); ?>"
                                   class="fl width-60 mar-right-10"/>
                            <select name="weight_unit" class="fl width-60" style="height:24px;padding:0px;">
                                <option value="kg" <?php echo ($unit == 'kg') ? 'selected="selected"' : ''; ?> >
                                    <?php echo "kg" ?>
                                </option>
                                <option value="lb" <?php echo ($unit == 'lbs') ? 'selected="selected"' : ''; ?>>
                                    <?php echo "lbs" ?>
                                </option>
                            </select>
                        </div>
                        <div class="text_short">
                            <?php $order_id = ($session) ? $_SESSION['form_data']['egyexpress_shipment_info_reference'] : $order_id; ?>
                            <label><?php echo esc_html__('Reference', 'egyexpress'); ?></label><input type="text"
                                                                                                  id="egyexpress_shipment_info_reference"
                                                                                                  name="egyexpress_shipment_info_reference"
                                                                                                  value="<?php echo esc_attr($order_id) ?>"/>
                        </div>
                      
                            <?php $checkCountry = ($country1 == $country) ? true : false; ?>
                            
                           
                        
                        
                        
                        <div class="text_short">
                            <?php $amount1 = round($order->get_total(), 2);
                            $amount1 = ($payment_method == "cod") ? $amount1 : ""; ?>
                            <?php $amount1 = ($session) ? $_SESSION['form_data']['egyexpress_shipment_info_cod_amount'] : $amount1; ?>
                            <label><?php echo esc_html__('COD Amount', 'egyexpress'); ?></label><input class="" type="text"
                                                                                                   id="egyexpress_shipment_info_cod_amount"
                                                                                                   name="egyexpress_shipment_info_cod_amount"
                                                                                                   value="<?php echo esc_attr($amount1); ?>"/>
                        </div>
                       
                        <?php $custom_currency_hidden = ($session) ? $_SESSION['form_data']['egyexpress_shipment_currency_code_custom_hidden_item'] : get_woocommerce_currency(); ?>
                        <input class="" type="hidden" id="egyexpress_shipment_currency_code_custom_hidden_item"
                                                  name="egyexpress_shipment_currency_code_custom_hidden_item"
                                                  value="<?php echo esc_attr($custom_currency_hidden); ?>"/>               
                        <div class="text_short">
                            <?php $code_currency_code_custom1 = ($session) ? $_SESSION['form_data']['egyexpress_shipment_currency_code'] : get_woocommerce_currency(); ?>
                            <?php $code_currency_code_custom1 =  ($payment_method == "cod") ? $code_currency_code_custom1 : ""; ?>

                            <?php $code_currency_code_custom1 = ($session) ? $_SESSION['form_data']['egyexpress_shipment_currency_code'] : $code_currency_code_custom1; ?>
                            <label><?php echo esc_html__('COD Currency', 'egyexpress'); ?></label>
                            <input type="text" class="" id="egyexpress_shipment_currency_code"
                            name="egyexpress_shipment_currency_code" value="<?php echo esc_attr($code_currency_code_custom1); ?>"/>
                            
                        </div>
                       

                       
                       
                        
                        <div class="text_short">
                            <label><?php echo esc_html__('Description', 'egyexpress'); ?></label>
                            <textarea style="float: left;
                                         font-size: 11px;
                                         margin-bottom: 5px;
                                         margin-top: 2px;
                                         width: 202px;" rows="4" cols="31" type="text" id="egyexpress_shipment_description"
                                      name="egyexpress_shipment_description" ><?php
                                foreach ($order->get_items() as $item) {
                                    echo esc_textarea(' : ' . trim($item['name']. ' - ' . trim($item['quantity'] .' pcs. '
                                        )));
                                } ?>
                                    </textarea>
                           
                        </div>
                        <div class="text_short">
                            <label><?php echo esc_html__('Items Price', 'egyexpress'); ?></label><input type="text"
                                                                                                    id="egyexpress_shipment_info_items_subtotal"
                                                                                                    name="egyexpress_shipment_info_items_subtotal"
                                                                                                    disabled="disabled"
                                                                                                    style="width: 165px; float: left;"
                                                                                                    value="<?php echo esc_attr($order->get_total()); ?>"/>

                         <div style="float: left; padding-left: 5px;"><?php echo esc_html(get_woocommerce_currency()); ?></div>
                        </div>
                        <div class="text_short">
                            <?php $egyexpress_number_pieces = ($session) ? $_SESSION['form_data']['number_pieces'] : '1'; ?>
                            <label><?php echo esc_html__('Number of Pieces', 'egyexpress'); ?></label><input type="text"
                                                                                                         name="number_pieces"
                                                                                                         value="<?php echo esc_attr($egyexpress_number_pieces); ?>"
                                                                                                         style="width: 165px; float: left;"/>
                            <div style="float: left; padding-left: 5px;"></div>
                        </div>

                    </div>
                  
                    <div class="egyexpress_clearer"></div>
                </FIELDSET>
                <div class="egyexpress_clearer"></div>
                <div style="float: right;margin-bottom: 20px;margin-top: -11px;">
                    <?php
                    if (isset($_SESSION['form_data'])) {
                        unset($_SESSION['form_data']);
                    }
    if (isset($_SESSION['egyexpress_errors'])) {
        unset($_SESSION['egyexpress_errors']);
    }
    if ($egyexpress_return_button) {
        ?>
                                        <input name="egyexpress_return_shipment_creation_date" type="hidden" value="return"/>
                                       

                                    <?php 
    } else {
        ?>
                       
                        <div class="egyexpress_clearer"></div>
                        <input name="egyexpress_return_shipment_creation_date" type="hidden" value="create"/>
                        <button id="egyexpress_shipment_creation_submit_id" type="submit"
                                name="egyexpress_shipment_creation_submit"
                                class="button-primary"><?php echo esc_html__('Create Shipment', 'egyexpress'); ?>
                        </button>
                    <?php 
    } ?>
                    <button id="egyexpress_close" class="button-primary" type="button"><?php echo esc_html__('Close',
                            'egyexpress'); ?></button>
                </div>
            </form>
        </div>
    </div>
    <script>
        jQuery.noConflict();
        (function ($) {
            var egyexpress_shipment_shipper_name = document.getElementById('egyexpress_shipment_shipper_name').value;
            var egyexpress_shipment_shipper_email = document.getElementById('egyexpress_shipment_shipper_email').value;
            var egyexpress_shipment_shipper_company = document.getElementById('egyexpress_shipment_shipper_company').value;
            var egyexpress_shipment_shipper_street = document.getElementById('egyexpress_shipment_shipper_street').value;
            var egyexpress_shipment_shipper_country = document.getElementById('egyexpress_shipment_shipper_country').value;
            var egyexpress_shipment_shipper_city = document.getElementById('egyexpress_shipment_shipper_city').value;
            var egyexpress_shipment_shipper_postal = document.getElementById('egyexpress_shipment_shipper_postal').value;
            var egyexpress_shipment_shipper_state = document.getElementById('egyexpress_shipment_shipper_state').value;
            var egyexpress_shipment_shipper_phone = document.getElementById('egyexpress_shipment_shipper_phone').value;
            var egyexpress_shipment_receiver_name = document.getElementById('egyexpress_shipment_receiver_name').value;
            var egyexpress_shipment_receiver_email = document.getElementById('egyexpress_shipment_receiver_email').value;
            var egyexpress_shipment_receiver_company = document.getElementById('egyexpress_shipment_receiver_company').value;
            var egyexpress_shipment_receiver_street = document.getElementById('egyexpress_shipment_receiver_street').value;
            var egyexpress_shipment_receiver_country = document.getElementById('egyexpress_shipment_receiver_country').value;
            var egyexpress_shipment_receiver_city = document.getElementById('egyexpress_shipment_receiver_city').value;
            var egyexpress_shipment_receiver_postal = document.getElementById('egyexpress_shipment_receiver_postal').value;
            var egyexpress_shipment_receiver_state = document.getElementById('egyexpress_shipment_receiver_state').value;
            var egyexpress_shipment_receiver_phone = document.getElementById('egyexpress_shipment_receiver_phone').value;

            jQuery(document).ready(function ($) {
                $("#egyexpress_shipment_info_billing_account_id").change(function () {
                    resetShipperDetail(this);
                });
            });

            function resetShipperDetail(el) {
                //alert(el.value);
                var elValue = el.value;
                var flag = 0;
                if (elValue == 2) {

                    document.getElementById('egyexpress_shipment_shipper_name').value = egyexpress_shipment_receiver_name;
                    document.getElementById('egyexpress_shipment_shipper_email').value = egyexpress_shipment_receiver_email;
                    document.getElementById('egyexpress_shipment_shipper_company').value = egyexpress_shipment_receiver_company;
                    document.getElementById('egyexpress_shipment_shipper_street').value = egyexpress_shipment_receiver_street;
                    document.getElementById('egyexpress_shipment_shipper_country').value = egyexpress_shipment_receiver_country;
                    document.getElementById('egyexpress_shipment_shipper_city').value = egyexpress_shipment_receiver_city;
                    document.getElementById('egyexpress_shipment_shipper_postal').value = egyexpress_shipment_receiver_postal;
                    document.getElementById('egyexpress_shipment_shipper_state').value = egyexpress_shipment_receiver_state;
                    document.getElementById('egyexpress_shipment_shipper_phone').value = egyexpress_shipment_receiver_phone;
                    document.getElementById('egyexpress_shipment_receiver_name').value = egyexpress_shipment_shipper_name;
                    document.getElementById('egyexpress_shipment_receiver_email').value = egyexpress_shipment_shipper_email;
                    document.getElementById('egyexpress_shipment_receiver_company').value = egyexpress_shipment_shipper_company;
                    document.getElementById('egyexpress_shipment_receiver_street').value = egyexpress_shipment_shipper_street;
                    document.getElementById('egyexpress_shipment_receiver_country').value = egyexpress_shipment_shipper_country;
                    document.getElementById('egyexpress_shipment_receiver_city').value = egyexpress_shipment_shipper_city;
                    document.getElementById('egyexpress_shipment_receiver_postal').value = egyexpress_shipment_shipper_postal;
                    document.getElementById('egyexpress_shipment_receiver_state').value = egyexpress_shipment_shipper_state;
                    document.getElementById('egyexpress_shipment_receiver_phone').value = egyexpress_shipment_shipper_phone;
                    document.getElementById('egyexpress_shipment_info_payment_type').value = 'C';
                    flag = 1;
                } else if (elValue == 3) {
                	/*
                    document.getElementById('egyexpress_shipment_shipper_name').value = "";
                    document.getElementById('egyexpress_shipment_shipper_email').value = "";
                    document.getElementById('egyexpress_shipment_shipper_company').value = "";
                    document.getElementById('egyexpress_shipment_shipper_street').value = "";
                    document.getElementById('egyexpress_shipment_shipper_country').value = "";
                    document.getElementById('egyexpress_shipment_shipper_city').value = "";
                    document.getElementById('egyexpress_shipment_shipper_postal').value = "";
                    document.getElementById('egyexpress_shipment_shipper_state').value = "";
                    document.getElementById('egyexpress_shipment_shipper_phone').value = "";
                    */
                    document.getElementById('egyexpress_shipment_info_payment_type').value = '3';
                    document.getElementById('ASCC').style.display = 'block';
                    document.getElementById('ARCC').style.display = 'block';
                    document.getElementById('CASH').style.display = 'none';
                    document.getElementById('ACCT').style.display = 'none';
                    document.getElementById('PPST').style.display = 'none';
                    document.getElementById('CRDT').style.display = 'none';
                    $('#egyexpress_shipment_info_payment_option').val("");
                    flag = 2;
                } else {
                    if (flag = 1) {
                        document.getElementById('egyexpress_shipment_receiver_name').value = egyexpress_shipment_receiver_name;
                        document.getElementById('egyexpress_shipment_receiver_email').value = egyexpress_shipment_receiver_email;
                        document.getElementById('egyexpress_shipment_receiver_company').value = egyexpress_shipment_receiver_company;
                        document.getElementById('egyexpress_shipment_receiver_street').value = egyexpress_shipment_receiver_street;
                        document.getElementById('egyexpress_shipment_receiver_country').value = egyexpress_shipment_receiver_country;
                        document.getElementById('egyexpress_shipment_receiver_city').value = egyexpress_shipment_receiver_city;
                        document.getElementById('egyexpress_shipment_receiver_postal').value = egyexpress_shipment_receiver_postal;
                        document.getElementById('egyexpress_shipment_receiver_state').value = egyexpress_shipment_receiver_state;
                        document.getElementById('egyexpress_shipment_receiver_phone').value = egyexpress_shipment_receiver_phone;
                        document.getElementById('egyexpress_shipment_shipper_name').value = egyexpress_shipment_shipper_name;
                        document.getElementById('egyexpress_shipment_shipper_email').value = egyexpress_shipment_shipper_email;
                        document.getElementById('egyexpress_shipment_shipper_company').value = egyexpress_shipment_shipper_company;
                        document.getElementById('egyexpress_shipment_shipper_street').value = egyexpress_shipment_shipper_street;
                        document.getElementById('egyexpress_shipment_shipper_country').value = egyexpress_shipment_shipper_country;
                        document.getElementById('egyexpress_shipment_shipper_city').value = egyexpress_shipment_shipper_city;
                        document.getElementById('egyexpress_shipment_shipper_postal').value = egyexpress_shipment_shipper_postal;
                        document.getElementById('egyexpress_shipment_shipper_state').value = egyexpress_shipment_shipper_state;
                        document.getElementById('egyexpress_shipment_shipper_phone').value = egyexpress_shipment_shipper_phone;
                        document.getElementById('egyexpress_shipment_info_payment_type').value = 'P';
                        document.getElementById('ASCC').style.display = 'none';
                        document.getElementById('ARCC').style.display = 'none';
                        document.getElementById('CASH').style.display = 'block';
                        document.getElementById('ACCT').style.display = 'block';
                        document.getElementById('PPST').style.display = 'block';
                        document.getElementById('CRDT').style.display = 'block';
                        $('#egyexpress_shipment_info_payment_option').val("");


                    } else if (flag = 2) {
                        document.getElementById('egyexpress_shipment_shipper_name').value = egyexpress_shipment_shipper_name;
                        document.getElementById('egyexpress_shipment_shipper_email').value = egyexpress_shipment_shipper_email;
                        document.getElementById('egyexpress_shipment_shipper_company').value = egyexpress_shipment_shipper_company;
                        document.getElementById('egyexpress_shipment_shipper_street').value = egyexpress_shipment_shipper_street;
                        document.getElementById('egyexpress_shipment_shipper_country').value = egyexpress_shipment_shipper_country;
                        document.getElementById('egyexpress_shipment_shipper_city').value = egyexpress_shipment_shipper_city;
                        document.getElementById('egyexpress_shipment_shipper_postal').value = egyexpress_shipment_shipper_postal;
                        document.getElementById('egyexpress_shipment_shipper_state').value = egyexpress_shipment_shipper_state;
                        document.getElementById('egyexpress_shipment_shipper_phone').value = egyexpress_shipment_shipper_phone;
                        document.getElementById('egyexpress_shipment_receiver_name').value = egyexpress_shipment_receiver_name;
                        document.getElementById('egyexpress_shipment_receiver_email').value = egyexpress_shipment_receiver_email;
                        document.getElementById('egyexpress_shipment_receiver_company').value = egyexpress_shipment_receiver_company;
                        document.getElementById('egyexpress_shipment_receiver_street').value = egyexpress_shipment_receiver_street;
                        document.getElementById('egyexpress_shipment_receiver_country').value = egyexpress_shipment_receiver_country;
                        document.getElementById('egyexpress_shipment_receiver_city').value = egyexpress_shipment_receiver_city;
                        document.getElementById('egyexpress_shipment_receiver_postal').value = egyexpress_shipment_receiver_postal;
                        document.getElementById('egyexpress_shipment_receiver_state').value = egyexpress_shipment_receiver_state;
                        document.getElementById('egyexpress_shipment_receiver_phone').value = egyexpress_shipment_receiver_phone;
                        document.getElementById('egyexpress_shipment_info_payment_type').value = 'C';
                        document.getElementById('ASCC').style.display = 'none';
                        document.getElementById('ARCC').style.display = 'none';
                        document.getElementById('CASH').style.display = 'block';
                        document.getElementById('ACCT').style.display = 'block';
                        document.getElementById('PPST').style.display = 'block';
                        document.getElementById('CRDT').style.display = 'block';

                        $('#egyexpress_shipment_info_payment_option').val("");
                    }
                    flag = 0;
                }
                /* hot fix  P.R */
                $(".egyexpress_countries").trigger('change');
            }

            $('#egyexpress_shipment_info_payment_type').change(function () {
                if ($('#egyexpress_shipment_info_payment_type').val() == "P") {
                    document.getElementById('ASCC').style.display = 'none';
                    document.getElementById('ARCC').style.display = 'none';
                    document.getElementById('CASH').style.display = 'block';
                    document.getElementById('ACCT').style.display = 'block';
                    document.getElementById('PPST').style.display = 'block';
                    document.getElementById('CRDT').style.display = 'block';
                    $('#egyexpress_shipment_info_payment_option').val("");
                } else {
                    document.getElementById('ASCC').style.display = 'block';
                    document.getElementById('ARCC').style.display = 'block';
                    document.getElementById('CASH').style.display = 'none';
                    document.getElementById('ACCT').style.display = 'none';
                    document.getElementById('PPST').style.display = 'none';
                    document.getElementById('CRDT').style.display = 'none';
                    $('#egyexpress_shipment_info_payment_option').val("");

                }
            });

            <?php
            if (strpos($currentUrl, "egyexpresspopup/show")) {
                ?>
            egyexpresspop();

            function egyexpresspop() {
                $("#egyexpress_overlay").css("display", "block");
                $("#egyexpress_shipment").css("display", "block");
                $("#egyexpress_shipment_creation").fadeIn(1000);
            }
            <?php

            } ?>

            $("input[name=egyexpress_shipment_info_shipping_charges]").change(function () {
                var cod_value = parseFloat($("input[name=egyexpress_shipment_info_shipping_charges]").val()) + parseFloat($("input[name=egyexpress_shipment_info_items_subtotal]").val());
                $("input[name=egyexpress_shipment_info_cod_value]").val(cod_value);
            });


            $("#egyexpress_shipment_info_product_group").change(function () {

                if ($("select[name=egyexpress_shipment_info_product_group]").val() == 'EXP') {
                    $("select[name=egyexpress_shipment_info_additional_services] option:selected").removeAttr("selected");
                    $("select[name=egyexpress_shipment_info_additional_services] .express_service").attr("selected", "selected");
                    $("#egyexpress_shipment_info_product_type option").hide();


                } else if ($("select[name=egyexpress_shipment_info_product_group]").val() == 'DOM') {
                    $("select[name=egyexpress_shipment_info_additional_services] option:selected").removeAttr("selected");
                    $("select[name=egyexpress_shipment_info_additional_services] .domestic_service").attr("selected", "selected");
                    $("#egyexpress_shipment_info_product_type option").hide();

                }
                $("#egyexpress_shipment_info_service_type_div").html($("select[name=egyexpress_shipment_info_service_type] option:selected").text());
                $("#egyexpress_shipment_info_additional_services_div").html($("select[name=egyexpress_shipment_info_additional_services] option:selected").text());

            });
            $("#egyexpress_shipment_info_product_group_div").html($("select[name=egyexpress_shipment_info_product_group] option:selected").text());
            $("#egyexpress_shipment_info_service_type_div").html($("select[name=egyexpress_shipment_info_service_type] option:selected").text());
            $("#egyexpress_shipment_info_additional_services_div").html($("select[name=egyexpress_shipment_info_additional_services] option:selected").text());

            $("#TaxPaid").change(function () {
                if ($("#TaxPaid").val() == 1)
                    $("#taxAmountBlock").fadeIn(500);
                else
                    $("#taxAmountBlock").fadeOut(500);
                    document.getElementById('TaxAmount').value = "";
            })

            $("#egyexpress_shipment_shipper_country").change(function () {
                if ($("#egyexpress_shipment_shipper_country").val() == "IN" && $("#egyexpress_shipment_receiver_country").val() != "IN")
                    $("#indianFields").fadeIn(500);
                else
                    $("#indianFields").fadeOut(500);
            })

            $(document).ready(function () {
                var currentDate = new Date();
                var currentYear = currentDate.getFullYear();
                var currentMonth = currentDate.getMonth() + 1;
                var currentDay = currentDate.getDate();
                $("#InvoiceDate").prop('max', currentYear + "-" + currentMonth + "-" + currentDay);

                if (($('#egyexpress_messages').html() != "") && ($('.error-msg'))) {
                    $("#egyexpress_overlay").css("display", "block");
                    $("#egyexpress_shipment_creation").fadeIn(1000);
                }

                if ($("#egyexpress_shipment_shipper_country").val() == "IN" && $("#egyexpress_shipment_receiver_country").val() != "IN")
                    { $("#indianFields").fadeIn(500); }
                $(function () {
                    $("#egyexpress_shipment_info_pickup_date").datepicker({dateFormat: "yy-mm-dd"});
                    $("#egyexpress_shipment_info_ready_time").datepicker({dateFormat: "yy-mm-dd"});
                    $("#egyexpress_shipment_info_last_pickup_time").datepicker({dateFormat: "yy-mm-dd"});
                    $("#egyexpress_shipment_info_closing_time").datepicker({dateFormat: "yy-mm-dd"});
                });

                $('#filereset').click(function () {
                    $("#file1_div").html($("#file1_div").html());
                });
                $('#file2reset').click(function () {
                    $("#file2_div").html($("#file2_div").html());
                });
                $('#file3reset').click(function () {
                    $("#file3_div").html($("#file3_div").html());
                });

                $("#egyexpress_shipment_info_product_type").chained("#egyexpress_shipment_info_product_group");
                $("#egyexpress_shipment_info_service_type").chained("#egyexpress_shipment_info_product_group");

                $("#egyexpress_return_shipment_creation_submit_id").click(function () {
                    $('.loading-mask').css('display', 'block');
                });
                $("#egyexpress_shipment_creation_submit_id").click(function () {
                    $('.loading-mask').css('display', 'block');
                });
            });


        })(jQuery);
    </script>

    <style>
        .ui-front {
            z-index: 10000000;
        }

        .ui-autocomplete {
            max-height: 200px;
            overflow-y: auto;
            /* prevent horizontal scrollbar */
            overflow-x: hidden;
            /* add padding to account for vertical scrollbar */
        }
    </style>
    <script type="text/javascript">
        jQuery(document).ready(function () {
            <?php
            if ($egyexpress_return_button === true) {
                ?>
            jQuery("#egyexpress_shipment_info_billing_account_id").val(2);
            jQuery("#egyexpress_shipment_info_billing_account_id").trigger('change');
            <?php 
            } ?>

            <?php
            $settings = new egyexpress_Shipping_Method();
    $allowed = $settings->settings['apilocationvalidator_active']; ?>
            var egyexpress_allow = "<?php echo esc_html($allowed); ?>";
            /* block script running*/
            if (egyexpress_allow == 0) {
                return false;
            }

            /* billing_egyexpress_cities and  shipping_egyexpress_cities */
            var type = '.egyexpress_shipment_creation_fieldset_left';
            setAutocomplate(type);
            var type = '.egyexpress_shipment_creation_fieldset_right';
            setAutocomplate(type);

            var type = '.egyexpress_top';
            setAutocomplate(type);
            var type = '.egyexpress_bottom';
            setAutocomplate(type);
            var type = '.schedule-pickup-part';
            setAutocomplate(type);

            function setAutocomplate(type) {
                var shippingegyexpressCitiesObj;
                var shipping_egyexpress_cities_temp;
                var billing_egyexpress_cities = '';
                var shipping_egyexpress_cities = billing_egyexpress_cities;

                /* set HTML blocks */
                shipping_egyexpress_cities_temp = shipping_egyexpress_cities;

                /* get egyexpress sities */
                shippingegyexpressCitiesObj = AutoSearchControls(type, shipping_egyexpress_cities);
                jQuery(type).find(".egyexpress_countries").change(function () {
                    getAllCitiesJson(type, shippingegyexpressCitiesObj);
                });
                getAllCitiesJson(type, shippingegyexpressCitiesObj);

                function AutoSearchControls(type, search_city) {

                    return jQuery(type).find(".egyexpress_city")
                        .autocomplete({
                            /*source: search_city,*/
                            minLength: 3,
                            scroll: true,
                            source: function (req, responseFn) {
                                var re = $.ui.autocomplete.escapeRegex(req.term);
                                var matcher = new RegExp("^" + re, "i");
                                var a = jQuery.grep(search_city, function (item, index) {
                                    return matcher.test(item);
                                });
                                responseFn(a);
                            },
                            search: function (event, ui) {
                                /* open initializer */

                            },
                            response: function (event, ui) {
                                var temp_arr = [];
                                jQuery(ui.content).each(function (i, v) {
                                    temp_arr.push(v.value);
                                });

                                return temp_arr;
                            }
                        });
                }

                function getAllCitiesJson(type, egyexpressCitiesObj) {
                    var country_code = jQuery(type).find(".egyexpress_countries").val();
                    var _wpnonce = "<?php echo esc_js(wp_create_nonce('egyexpress-shipment-check' . wp_get_current_user()->user_email)); ?>";


                        var url_check = "<?php echo admin_url('admin-ajax.php'); ?>?country_code=" + country_code + '&_wpnonce=' + _wpnonce+ "&action=the_egyexpress_searchautocities&backend=backend";





                    shipping_egyexpress_cities_temp = '';

                    egyexpressCitiesObj.autocomplete("option", "source", url_check);
                }
            }
        });
     </script>
    <?php
    $history = get_comments(array(
        'post_id' => $order_id,
        'orderby' => 'comment_ID',
        'order' => 'DESC',
        'approve' => 'approve',
        'type' => 'order_note',
    ));

    $history_list = array();
    foreach ($history as $shipment) {
        $history_list[] = $shipment->comment_content;
    }
    $last_track = "";
    if (count($history_list)) {
        foreach ($history_list as $history) {
            $awbno = strstr($history, "- Order No", true);
            $awbno = trim($awbno, "AWB No.");
            if (isset($awbno)) {
                if ((int)$awbno) {
                    $last_track = $awbno;
                    break;
                }
            }
            $awbno = trim($awbno, "egyexpress Shipment Return Order AWB No.");
            if (isset($awbno)) {
                if ((int)$awbno) {
                    $last_track = $awbno;
                    break;
                }
            }
        }
    } ?>
              <script type="text/javascript">
                jQuery.noConflict();
                (function ($) {
                    $(document).ready(function () {
                        $('#print_egyexpress_shipment').click(function () {
                            sendAjax();
                        });
                        $('.print_egyexpress_shipment').click(function () {
                            sendAjax();
                        });
                        function sendAjax(){
                        var postData = {
                        action: 'the_egyexpress_print_lable',
                        egyexpress_printlabel:"<?php echo esc_attr($order_id); ?>",
                        egyexpress_lasttrack: $('#egyexpress-lasttrack-field').val(),
                        _wpnonce:"<?php echo esc_attr(wp_create_nonce('egyexpress-shipment-check' . wp_get_current_user()->user_email)); ?>"
                    };

                    jQuery.post(ajaxurl, postData, function(request) {

                        // add my code here
                        const linkSource = `data:application/pdf;base64,${request}`;
                        const downloadLink = document.createElement("a");
                        const fileName =  `egypt_exprss_print-${Date.now()}.pdf`;

                        downloadLink.href = linkSource;
                        downloadLink.download = fileName;
                        downloadLink.click();

                       // window.location.href = request;
                    });                            
                            
                        }
                        $('#printlabel_close').click(function () {
                            $('.printlabel_overlay').css("display", "none");
                        });
                    });
                })(jQuery);

            </script>
<?php 
}
