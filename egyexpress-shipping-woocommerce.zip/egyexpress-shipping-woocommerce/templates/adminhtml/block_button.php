<?php
/*
Plugin Name:  egyexpress Shipping WooCommerce
Plugin URI:   https://egyexpress.com
Description:  egyexpress Shipping WooCommerce plugin
Version:      1.0.0
Author:       egyexpress.com
Author URI:   https://www.egyexpress.com/solutions-services/developers-solutions-center
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  egyexpress
Domain Path:  /languages
*/
?>
<?php
        /**
         *  Render "Block" button
         *
         * @return string Template
         */
function block_button()
{
    #$egyexpress_error = WC()->session->get('egyexpress_error');
}
?>
    <?php 
    $settings = new egyexpress_Shipping_Method();
    $rate_calculator_checkout_page = $settings->settings['rate_calculator_checkout_page'];
    if ($rate_calculator_checkout_page == 1) {
        ?>

<script type="text/javascript">
    jQuery.noConflict();
    (function ($) {
        var egyexpress_error = "<?php echo(esc_js(WC()->session->get('egyexpress_error'))); ?>";
        var egyexpress_block = "<?php echo(esc_js(WC()->session->get('egyexpress_block'))); ?>";
        if(egyexpress_block !== "1"){
        block_button();
        }
        function block_button() {
            if (egyexpress_error == true) {
                $("#place_order").prop("disabled", true);
            } else {
                $("#place_order").prop("enable", true);
            }
        }
        $(".woocommerce-error").css("display", "none");

    })(jQuery);
</script>

   <?php 
    }
