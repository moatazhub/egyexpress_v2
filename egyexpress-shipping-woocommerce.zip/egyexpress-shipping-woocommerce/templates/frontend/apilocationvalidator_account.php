<?php
/*
Plugin Name:  egyexpress Shipping WooCommerce
Plugin URI:   https://egyexpress.com
Description:  egyexpress Shipping WooCommerce plugin
Version:      1.0.0
Author:       egyexpress.com
Author URI:   https://www.egyexpress.com/solutions-services/developers-solutions-center
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  egyexpress
Domain Path:  /languages
*/
?>
<?php
        /**
         *  Render "Validator" form
         *
         * @return string Template
         */
function egyexpress_display_apilocationvalidator_in_account()
{
    require_once __DIR__ . '/../../includes/shipping/class-egyexpress-woocommerce-shipping.php';
    $settings = new egyexpress_Shipping_Method();
    $allowed = $settings->settings['apilocationvalidator_active'];
    $rate_calculator_checkout_page = $settings->settings['rate_calculator_checkout_page'];
    if ($allowed == 1 && $rate_calculator_checkout_page == 1) {
        $ajax_nonce_serchautocities = wp_create_nonce("serchautocities"); ?>
        <script type="text/javascript">
            jQuery.noConflict();
            (function ($) {
                $(document).ready(function () {
                    var type = 'billing';
                    Go(type);
                    var type = 'shipping';
                    Go(type);

                    function Go(type) {
                        var button = '.woocommerce-address-fields .button';
                        var shippingegyexpressCitiesObj;
                        /* set HTML blocks */
                        jQuery(".woocommerce-address-fields").find('input[name^= "' + type + '_city"]').after('<div id="egyexpress_loader" style="height:31px; width:31px; display:none;"></div>');
                        /* get egyexpress sities */
                        shippingegyexpressCitiesObj = AutoSearchControls(type, "");
                        jQuery(".woocommerce-address-fields").find('select[name^= "' + type + '_country"]').change(function () {
                            jQuery('.woocommerce-address-fields').find('input[name^= "' + type + '_city"]').val("");
                            getAllCitiesJson(type, shippingegyexpressCitiesObj);
                        });
                        getAllCitiesJson(type, shippingegyexpressCitiesObj);

                        function AutoSearchControls(type, search_city) {
                            return jQuery('.woocommerce-address-fields').find('input[name^= "' + type + '_city"]')
                                .autocomplete({
                                    /*source: search_city,*/
                                    minLength: 3,
                                    scroll: true,
                                    source: function (req, responseFn) {
                                        var re = $.ui.autocomplete.escapeRegex(req.term);
                                        var matcher = new RegExp("^" + re, "i");
                                        var a = jQuery.grep(search_city, function (item, index) {
                                            return matcher.test(item);
                                        });
                                        responseFn(a);
                                    },
                                    search: function (event, ui) {
                                        /* open initializer */
                                        jQuery('.woocommerce-address-fields .ui-autocomplete').css('display', 'none');
                                        jQuery('.woocommerce-address-fields #egyexpress_loader').css('display', 'block');
                                    },
                                    response: function (event, ui) {
                                        var temp_arr = [];
                                        jQuery(ui.content).each(function (i, v) {
                                            temp_arr.push(v.value);
                                        });
                                        jQuery('.woocommerce-address-fields #egyexpress_loader').css('display', 'none');
                                        return temp_arr;
                                    }
                                });
                        }

                        function getAllCitiesJson(type, egyexpressCitiesObj) {
                            var country_code = jQuery('.woocommerce-address-fields').find('select[name^= "' + type + '_country"]').val();

                        var url_check = "<?php echo admin_url('admin-ajax.php'); ?>?country_code=" + country_code + "&security=<?php echo esc_html($ajax_nonce_serchautocities); ?>"  + "&action=the_egyexpress_searchautocities";

                            egyexpressCitiesObj.autocomplete("option", "source", url_check);
                        }

                        /* make validation */
                        bindIvents(type, button);

                        function bindIvents(type, button) {
                            jQuery('.woocommerce-address-fields').find('input[name^= "' + type + '_city"]').blur(function () {
                                addressApiValidation(type, button);
                            });

                            jQuery('.woocommerce-address-fields').find('input[name^= "' + type + '_address_1"]').blur(function () {
                                addressApiValidation(type, button);
                            });
                            jQuery('.woocommerce-address-fields').find('input[name^= "' + type + '_postcode"]').blur(function () {
                                addressApiValidation(type, button);
                            });

                        }

                        function addressApiValidation(type, button) {
                            var chk_city = jQuery('.woocommerce-address-fields').find('input[name^= "' + type + '_city"]').val();
                            var chk_region_id = jQuery('.woocommerce-address-fields').find('input[name^= "' + type + '_address_1"]').val();
                            var chk_postcode = jQuery('.woocommerce-address-fields').find('input[name^= "' + type + '_postcode"]').val();
                            var country_code = jQuery('.woocommerce-address-fields').find('select[name^= "' + type + '_country"]').val();
                            if (chk_region_id == '' || chk_city == '' || chk_postcode == '') {
                                return false;
                            } else {
                                jQuery(button).prop("disabled", true);
                                var postData = {
                                        action: 'the_egyexpress_appyvalidation',
                                        city: chk_city,
                                        post_code: chk_postcode,
                                        country_code: country_code,
                                        security: '<?php echo esc_html($ajax_nonce_serchautocities); ?>',

        };
               
        jQuery.post('<?php echo admin_url('admin-ajax.php'); ?>', postData, function(result) {
                                        var response = JSON.parse(result);
                                        if (!(response.suggestedAddresses) && response.message != '' && response.message !== undefined) {
                                            if (response.message.indexOf("City") != -1) {
                                                if (jQuery('.woocommerce-address-fields').find('input[name^= "' + type + '_city"]').val() != "") {
                                                    if (response.message !== undefined) {
                                                        alert(response.message);
                                                    }
                                                }
                                                jQuery('.woocommerce-address-fields').find('input[name^= "' + type + '_city"]').val("");
                                            }
                                            if (response.message.indexOf("zip") != -1) {
                                                if (jQuery('.woocommerce-address-fields').find('input[name^= "' + type + '_postcode"]').val() != "") {
                                                    if (response.message !== undefined) {
                                                        alert(response.message);
                                                    }
                                                }
                                                jQuery('.woocommerce-address-fields').find('input[name^= "' + type + '_postcode"]').val("");
                                            }
                                        } else if (response.suggestedAddresses) {
                                            jQuery('.woocommerce-address-fields').find('input[name^= "' + type + '_city"]').val("");
                                        }
                                        jQuery(button).prop("disabled", false);
                                                     
        });  

                            }
                        }
                    }
                });
            })(jQuery);
        </script>
        <style>
            #egyexpress_loader {
                background-image: url(<?php echo plugins_url() . '/egyexpress-shipping-woocommerce/assets/img/egyexpress_loader.gif'; ?>);
            }

            .ui-autocomplete {
                max-height: 200px;
                overflow-y: auto;
                /* prevent horizontal scrollbar */
                overflow-x: hidden;
                /* add padding to account for vertical scrollbar */
            }

            .required-egyexpress:before {
                content: '* ' !important;
                color: #F00 !important;
                font-weight: bold !important;
            }
        </style>
    <?php 
    }
}