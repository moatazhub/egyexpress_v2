<?php
/*
Plugin Name:  egyexpress Shipping WooCommerce
Plugin URI:   https://egyexpress.com
Description:  egyexpress Shipping WooCommerce plugin
Version:      1.0.0
Author:       egyexpress.com
Author URI:   https://www.egyexpress.com/solutions-services/developers-solutions-center
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  egyexpress
Domain Path:  /languages
*/


return array(
    'enabled' => array(
        'title' => __('Enable', 'egyexpress'),
        'type' => 'checkbox',
        'description' => __('Enable egyexpress shipping', 'egyexpress'),
        'default' => 'yes'
    ),
    'title' => array(
        'title' => __('Title', 'egyexpress'),
        'type' => 'text',
        'description' => __('Title to be display on site', 'egyexpress'),
        'default' => __('egyexpress Shipping', 'egyexpress')
    ),

    'freight' => array(
        'title' => __('Client information', 'egyexpress'),
        'type' => 'title',
    ),
    'account_pin' => array(
        'title' => __('* Account Username', 'egyexpress'),
        'type' => 'text',
    ),
    'account_number' => array(
        'title' => __('* Account Number', 'egyexpress'),
        'type' => 'text',
    ),
    'password' => array(
        'title' => __('* Password', 'egyexpress'),
        'type' => 'password',
    ),
    'user_name' => array(
        'title' => __('* Email', 'egyexpress'),
        'type' => 'text',
    ),
  
    'allowed_domestic_methods' => array(
        'title' => __('Product Type', 'egyexpress'),
        'type' => 'select',
       
        'options' => array(
            'DMS' => __('DMS - DEDICATED MESSEGNER SERVICE' , 'egexpress'),
            'DOX' => __('ng-star-inserted' , 'egexpress'),
            'FRE' => __('ng-star-inserted' , 'egexpress'),
            'INT' => __('INT - International Service' , 'egexpress'),
            
        )
    ),
    'allowed_domestic_additional_services' => array(
        'title' => __('Service Type', 'egyexpress'),
        'type' => 'select',
        
        'options' => array(
            'AFN' => __('AFN - AFTERNOON DELIVEREY' , 'egexpress'),
            'COD' => __('COD - CASH ON DLIVERY' , 'egexpress'),
            'DE' => __('DE - DOMESTIC ECONOMY' , 'egexpress'),
            'D2D' => __('D2D - Doort to Door Service' , 'egexpress'),
           
        )
    ),
    'allowed_international_methods' => array(
        'title' => __(''),
        'type' => 'multiselect',
        'css' => 'width: 350px; height: 150px;display: none',
        'options' => array(
            'DPX' => __('Value Express Parcels', 'egyexpress'),
            'EDX' => __('Economy Document Express', 'egyexpress'),
            'EPX' => __('Economy Parcel Express', 'egyexpress'),
            'GDX' => __('Ground Document Express', 'egyexpress'),
            'GPX' => __('Ground Parcel Express', 'egyexpress'),
            'IBD' => __('International defered', 'egyexpress'),
            'PDX' => __('Priority Document Express', 'egyexpress'),
            'PLX' => __('Priority Letter Express (<.5 kg Docs)', 'egyexpress'),
            'PPX' => __('Priority Parcel Express', 'egyexpress'),
            'ABX' => __('ABX', 'egyexpress')
        )
    ),
    'allowed_international_additional_services' => array(
        'title' => __('', 'egyexpress'),
        'type' => 'multiselect',
        'css' => 'width: 350px; height: 150px;display: none',
        'options' => array(
            'AM10' => __('Morning delivery', 'egyexpress'),
            'CODS' => __('Cash On Delivery', 'egyexpress'),
            'CSTM' => __('CSTM', 'egyexpress'),
            'EUCO' => __('NULL', 'egyexpress'),
            'FDAC' => __('FDAC', 'egyexpress'),
            'FRDM' => __('FRDM', 'egyexpress'),
            'INSR' => __('Insurance', 'egyexpress'),
            'NOON' => __('Noon Delivery', 'egyexpress'),
            'ODDS' => __('Over Size', 'egyexpress'),
            'RTRN' => __('RTRN', 'egyexpress'),
            'SIGR' => __('Signature Required', 'egyexpress'),
            'SPCL' => __('Special Services', 'egyexpress')

        )
    ),
    'freight2' => array(
        'title' => __('Shipper Details', 'egyexpress'),
        'type' => 'title',
    ),
    'name' => array(
        'title' => __('Name', 'egyexpress'),
        'type' => 'text',
    ),
    'email_origin' => array(
        'title' => __('Email', 'egyexpress'),
        'type' => 'text',
    ),
    'company' => array(
        'title' => __('Company', 'egyexpress'),
        'type' => 'text',
    ),
    'address' => array(
        'title' => __('Address', 'egyexpress'),
        'type' => 'text',
    ),
    'country' => array(
        'title' => __('* Country', 'egyexpress'),
        'type' => 'select',
        'options' => array(
            'EG' => __( 'Egypt', 'woocommerce' ),
        )
    ),
    'city' => array(
        'title' => __('* City', 'egyexpress'),
        'type' => 'text',
    ),
    'postalcode' => array(
        'title' => __('* Postal Code', 'egyexpress'),
        'type' => 'text',
    ),
    'state' => array(
        'title' => __('State', 'egyexpress'),
        'type' => 'select',
        'options' => array(
            'RAM' => __( '10th Of Ramadan', 'woocommerce' ),
            'MAY' => __( '15th Of May', 'woocommerce' ),
            'OCT' => __( '6th of October', 'woocommerce' ),
            'ABS' => __( 'Abou Sembel', 'woocommerce' ),
            'AAC' => __( 'Al Areesh', 'woocommerce' ),
            'ALX' => __( 'ALEXANDRIA', 'woocommerce' ),
            'SHA' => __( 'ALSHARKIA', 'woocommerce' ),
            'ASU' => __( 'ASSUIT', 'woocommerce' ),
            'ASW' => __( 'Aswan', 'woocommerce' ),
            'BAD' => __( 'Badr City', 'woocommerce' ),
            'BEH' => __( 'BEHARA', 'woocommerce' ),
            'BNS' => __( 'Beni-Sueif', 'woocommerce' ),
            'BRG' => __( 'Borg el Arab', 'woocommerce' ),
            'CAI' => __( 'CAIRO', 'woocommerce' ),
            'DHB' => __( 'Dahab', 'woocommerce' ),
            'DAK' => __( 'DAKAHLIA', 'woocommerce' ),
            'DAM' => __( 'DAMANHOUR', 'woocommerce' ),
            'QDX' => __( 'Damietta', 'woocommerce' ),
            'BAO' => __( 'El Bahareya Oasis', 'woocommerce' ),
            'GOU' => __( 'El Gouna', 'woocommerce' ),
            'MEN' => __( 'EL MONFIA', 'woocommerce' ),
            'SAF' => __( 'El Saff', 'woocommerce' ),
            'SALL' => __( 'El Salloum', 'woocommerce' ),
            'SHZ' => __( 'El Sheikh Zayed', 'woocommerce' ),
            'SHO' => __( 'El Shorouk', 'woocommerce' ),
            'TOU' => __( 'El Tour', 'woocommerce' ),
            'ELW' => __( 'EL WADI', 'woocommerce' ),
            'FAY' => __( 'FAYUOM', 'woocommerce' ),
            'GAR' => __( 'Garden City', 'woocommerce' ),
            'GHA' => __( 'GHARBEYA', 'woocommerce' ),
            'GIZ' => __( 'GIZA', 'woocommerce' ),
            'HAA' => __( 'Halayeb', 'woocommerce' ),
            'HEL' => __( 'Helopolis', 'woocommerce' ),
            'HLW' => __( 'HELWAN', 'woocommerce' ),
            'HUR' => __( 'Hurghada', 'woocommerce' ),
            'QIV' => __( 'Ismailia', 'woocommerce' ),
            'KAD' => __( 'KAFER EL DAWAR', 'woocommerce' ),
            'KAZ' => __( 'KAFR EL SHIKH', 'woocommerce' ),
            'KAL' => __( 'KALIUOB', 'woocommerce' ),
            'QOS' => __( 'Kosseir', 'woocommerce' ),
            'LXR' => __( 'Luxor', 'woocommerce' ),
            'MAD' => __( 'Maadi', 'woocommerce' ),
            'MNT' => __( 'Madinaty', 'woocommerce' ),
            'QEK' => __( 'Mahalla', 'woocommerce' ),
            'QSU' => __( 'Mansoura', 'woocommerce' ),
            'MRA' => __( 'MARSA ALLAM', 'woocommerce' ),
            'MUH' => __( 'Marsa Matrouh', 'woocommerce' ),
            'EMY' => __( 'Minya', 'woocommerce' ),
            'MOH' => __( 'MOHANDISEEN', 'woocommerce' ),
            'NCO' => __( 'NEW CAIRO STATION', 'woocommerce' ),
            'NOC' => __( 'North Coast', 'woocommerce' ),
            'NOS' => __( 'North Sinai', 'woocommerce' ),
            'NEW' => __( 'Nweiba`a', 'woocommerce' ),
            'OBR' => __( 'OBOUR', 'woocommerce' ),
            'OTH' => __( 'OUT STATION LOC', 'woocommerce' ),
            'OMO' => __( 'Oyoun Moussa', 'woocommerce' ),
            'PSD' => __( 'Port Said', 'woocommerce' ),
            'QNA' => __( 'QUNA', 'woocommerce' ),
            'RAS' => __( 'Rass Sedr', 'woocommerce' ),
            'RES' => __( 'Red Sea', 'woocommerce' ),
            'RHB' => __( 'Rehab City', 'woocommerce' ),
            'RNCO' => __( 'Retail 5th settlement', 'woocommerce' ),
            'RAIR' => __( 'RETAIL AIRPORT', 'woocommerce' ),
            'RAMR' => __( 'Retail Amrea', 'woocommerce' ),
            'RSMO' => __( 'RETAIL-SMOUHA', 'woocommerce' ),
            'RABOR' => __( 'RETAIL.SALAH SALEM', 'woocommerce' ),
            'SDT' => __( 'Sadat', 'woocommerce' ),
            'SFG' => __( 'Safaga', 'woocommerce' ),
            'SNK' => __( 'Saint Katherin', 'woocommerce' ),
            'SAK' => __( 'Sakkara', 'woocommerce' ),
            'SLO' => __( 'SALAH SALEM STATION', 'woocommerce' ),
            'SHT' => __( 'Shalatin', 'woocommerce' ),
            'SSH' => __( 'Sharm El Sheikh', 'woocommerce' ),
            'SIO' => __( 'Siwa Oasis', 'woocommerce' ),
            'QHX' => __( 'Sohag', 'woocommerce' ),
            'SKH' => __( 'Sokhna', 'woocommerce' ),
            'SOS' => __( 'South Sinai', 'woocommerce' ),
            'SUZ' => __( 'Suez', 'woocommerce' ),
            'TAB' => __( 'TABA', 'woocommerce' ),
            'QTT' => __( 'Tanta', 'woocommerce' ),
            'QZZ' => __( 'Zakazeek', 'woocommerce' ),
        )
    ),
    'phone' => array(
        'title' => __('Phone', 'egyexpress'),
        'type' => 'text',
    ),
   
);
