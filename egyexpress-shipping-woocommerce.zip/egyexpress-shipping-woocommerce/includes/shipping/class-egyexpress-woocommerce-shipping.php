<?php
/*
Plugin Name:  egyexpress Shipping WooCommerce
Plugin URI:   https://egyexpress.com
Description:  egyexpress Shipping WooCommerce plugin
Version:      1.0.0
Author:       egyexpress.com
Author URI:   https://www.egyexpress.com/solutions-services/developers-solutions-center
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  egyexpress
Domain Path:  /languages
*/

if (!class_exists('egyexpress_Shipping_Method')) {

    /**
     * Controller for egyexpress shipping
     */
    class egyexpress_Shipping_Method extends WC_Shipping_Method
    {
        /**
         * egyexpress_Shipping_Method constructor
         *
         * @return void
         */
        public function __construct()
        {
            $this->id = 'egyexpress';
            $this->method_title = __('egyexpress Global Settings', 'egyexpress');
            $this->method_description = __('Shipping Method for egyexpress', 'egyexpress');
            $this->init();
            $this->enabled = isset($this->settings['enabled']) ? $this->settings['enabled'] : 'yes';
            $this->title = isset($this->settings['title']) ? $this->settings['title'] : __('egyexpress Shipping', 'egyexpress');
            include_once __DIR__ . '../../core/class-egyexpress-helper.php';
           
            add_filter( 'woocommerce_package_rates', array( $this , 'conditional_shipping' ), 10, 2 );
        }

        function conditional_shipping( $rates, $packages ) {
            foreach ( $rates as $rate_id => $rate ) {
                if($rate->method_id=='egyexpress'){
                    if(WC()->session->get('egyexpress_error')==1){
                        unset( $rates[$rate_id] );
                    }
                }
            }
            return $rates;
        }

        /**
         * Init your settings
         *
         * @return void
         */
        public function init()
        {
            // Load the settings API
            $this->init_form_fields();
            $this->init_settings();
            // Save settings in admin if you have any defined
            add_action('woocommerce_update_options_shipping_' . $this->id, array($this, 'process_admin_options'));
        }

        /**
         * Define settings field for this shipping
         * @return void
         */
        public function init_form_fields()
        {
            $this->form_fields = include('data-egyexpress-settings.php');
        }

        /**
         * This function is used to calculate the shipping cost. Within this function we can check for weights, dimensions and other parameters.
         *
         * @param array $package Package
         * @return void
         */
        public function calculate_shipping($package = array())
        {
            $settings = new egyexpress_Shipping_Method();
            $allowed_domestic_methods = $settings->form_fields['allowed_domestic_methods']['options'];
            $allowed_international_methods = $settings->form_fields['allowed_international_methods']['options'];
            $rate_calculator_checkout_page = $settings->settings['rate_calculator_checkout_page'];
            $rate_calculator_checkout_page_only_for_international = $settings->settings['rate_calculator_checkout_page_only_for_international'];
            // $weightUnit = get_option('woocommerce_weight_unit');
            // if ($weightUnit == 'lbs'){
            //     $weightUnit = 'lb';
            // }
            // if ($rate_calculator_checkout_page != 1) {
            //     return false;
            // }

            // $referer_parse = parse_url($_SERVER['REQUEST_URI']);
            // if (strpos($referer_parse['path'], '/product/')!==false) {
            //     return false;
            // }
            // $rate_calculator_checkout_page = $this->settings['rate_calculator_checkout_page'];
            // if ($rate_calculator_checkout_page == "0") {
            //     WC()->session->set('egyexpress_block', true);
            //     return false;
            // } else {
            //     WC()->session->set('egyexpress_block', false);
            // }
            // $pkgWeight = 0;
            // $pkgQty = 0;
            // $weight = 0;
            // foreach ($package['contents'] as $item_id => $values) {
            //     $product = $values['data'];
            //     if( $product->is_type( 'simple' ) ){
            //         // a simple product
            //         $array_weight = $product->get_data();
            //         $weight = $array_weight['weight'];

            //       } elseif( $product->is_type( 'variation' ) || $product->is_type( 'variable' ) ){
            //         // a variable product
            //         $array_weight = $product->get_data();
            //         if(empty($array_weight['weight'])){
            //             $parent_weight = $product->get_parent_data();
            //             $weight =  $parent_weight['weight'];
            //         }else{
            //             $weight = $array_weight['weight'];
            //         }
            //       }
            //     $pkgWeight = $pkgWeight + (float)$weight * $values['quantity'];
            //     $pkgQty = $pkgQty + $values['quantity'];
            // }
            // $product_group = 'EXP';
            // $allowed_methods = array();
            // $allowed_methods = $this->settings['allowed_international_methods'];
            // if (strtolower($this->settings['country']) == strtolower($package['destination']['country'])) {
            //     $product_group = 'DOM';
            //     $allowed_methods = $this->settings['allowed_domestic_methods'];
            // }
            // if(!empty($rate_calculator_checkout_page_only_for_international) && $product_group == 'DOM'){
            // 	WC()->session->set('egyexpress_block', false);
            // 	return;
            // }

            // $info = $this->getInfo(wp_create_nonce('egyexpress-shipment-check' . wp_get_current_user()->user_email));
            // if(!is_array($allowed_methods)){
            // 	return;
            // }




            $width = 0;
            $height = 0;
            $length = 0;
            $dimensions = 0;

            // $cities = array_flip(egexpress_shipping_cities_code_value());
            // $cities = egexpress_shipping_cities_code_value();



            $weight = 0;
            $cost = 0;
            $country = $package["destination"]["state"];
          //  wc_get_logger()->info( $country);
            foreach ($package['contents'] as $item_id => $values) {
                $_product = $values['data'];
                $weight = $weight + $_product->get_weight() * $values['quantity'];


                //  $length = $length + $_product->get_length() * $values['quantity'];
                // $width  = $width  + $_product->get_width()  * $values['quantity'];
                //  $height = $height + $_product->get_heigt()  * $values['quantity'];



           }



            $weight = wc_get_weight($weight, 'kg');

            $options = get_option('egexpress_options');

            // $response = wp_remote_post(EGYPT_EXPRESS_SHIPPING_CALCULATOR_URI, array('body' => array(
            //     'source' => $this->shipping_city,
            //     'destination' => $cities[$package["destination"]["city"]],
            //     'weight_unit' => 2,
            //     'weight' => $weight
            //     //'width' => $width,
            //     //'height' => $height,
            //     //'length' => $length
            //     )
            // ));

             $request_body = [];
                //$cites = [];
                $request_body['UserName'] = $this->settings['account_pin'];//$options['userName'];
                //Password To be provided by Fedex  
                wc_get_logger()->info( $this->settings['account_pin']);
                $request_body['Password'] = $this->settings['password']; //$options['password'];
                wc_get_logger()->info( $this->settings['password']);
                $request_body['Origin'] = $this->settings['state'];// $this->shipping_city;
                wc_get_logger()->info( $this->settings['state']);
                $request_body['Destination'] = $package["destination"]["state"];//$cities['Ismailia'];// 
                wc_get_logger()->info( $package["destination"]["state"]);
                $request_body['Dimension'] =  "1x1x1";
               // $request_body['PaymentMethod'] =  "AC";
                $request_body['ServiceType'] =  "FRG";
                $request_body['Product'] =  "FRE";
                $request_body['NoofPeices'] =  2;
                $request_body['Weight'] = $weight;
                wc_get_logger()->info( $weight);
                //global $woocommerce;
              //  $con =WC()->customer->get_shipping_state();
              //  wc_get_logger($con);


             // $track = $package["destination"]["state"];
             // wc_get_logger()->info( $track);

             $response = wp_remote_post('http://82.129.197.86:1929/EGEXPService.svc/RateFinder', array(
                'headers'     => array('Content-Type' => 'application/json; charset=utf-8'),
                 'body'       => json_encode($request_body)));

            // print_r($response);
            
            //  $response = wp_remote_post(EGYPT_EXPRESS_SHIPPING_CALCULATOR_URI, array('body' => array(
            //     'UserName' => $options['userName'],
            //     'Password' => $options['password'],
            //     'Origin' => $this->shipping_city,
            //     'Destination' => "QIV",//$cities[$package["destination"]["city"]],
            //     'Dimension' => '',
            //     "PaymentMethod" => 'AC',
            //     "ServiceType" => "FRG",
            //     "Product" => "FRE",
            //     'NoofPeices' => 2,
            //     'Weight' => $weight
            //     //'width' => $width,
            //     //'height' => $height,
            //     //'length' => $length
            //     )
            // ));


            if (is_wp_error($response)) {

              

                $error_message = $response->get_error_message();
                $rate = array(
                    'id' => $this->id,
                    'label' => $this->title,
                    'cost' => $this->fallback_price
                );
            } else {
               
                $body = json_decode(wp_remote_retrieve_body($response));
              //  print_r($body);
                if($body->Code == 1) {
                    $rate = array(
                        'id' => $this->id,
                        'label' => $this->title,
                        'cost' => $body->NetAmount
                    );
                } else {

                    $rate = array(
                        'id' => $this->id,
                        'label' => $this->title,
                        'cost' => $this->fallback_price
                    );
                }
            }


           


//               $customPrice = 0;
//               if (!$cities[$package["destination"]["city"]] )
//                   $customPrice = 0;
//               else
//                   $customPrice = 80;
//
//
//
//                $rate = array(
//                    'id' => $this->id,
//                    'label' => $this->title,
//                    'cost' => $customPrice
//                );


            $this->add_rate($rate);
            



            // foreach ($allowed_methods as $key => $allowed_method) {
            //     $price = "";
            //     $curr_code = "";
            //     $OriginAddress = array(
            //         'StateOrProvinceCode' => $this->settings['state'],
            //         'City' => $this->settings['city'],
            //         'PostCode' => str_replace(" ","",$this->settings['postalcode']),
            //         'CountryCode' => $this->settings['country'],
            //     );

            //     $DestinationAddress = array(
            //         'StateOrProvinceCode' => $package['destination']['state'],
            //         'City' => $package['destination']['city'],
            //         'PostCode' => str_replace(" ","",$package['destination']['postcode']),
            //         'CountryCode' => $package['destination']['country'],
            //     );
            //     $ShipmentDetails = array(
            //         'PaymentType' => 'P',
            //        // 'PaymentOptions' => 'ACCT',
            //         'ProductGroup' => $product_group,
            //         'ProductType' => $allowed_method,
            //         'ActualWeight' => array('Value' => $pkgWeight, 'Unit' => $weightUnit),
            //         'ChargeableWeight' => array('Value' => $pkgWeight, 'Unit' => $weightUnit),
            //         'NumberOfPieces' => $pkgQty
            //     );

            //     //SOAP object
            //     $soapClient = new SoapClient($info['baseUrl'] . 'egyexpress-rates-calculator-wsdl.wsdl',
            //         array("trace" => true, 'cache_wsdl' => WSDL_CACHE_NONE));
            //     //$baseCurrencyCode = get_woocommerce_currency();
            //     $baseCurrencyCode = get_option('woocommerce_currency');
                
            //     $params = array(
            //         'ClientInfo' => $info['clientInfo'],
            //         'OriginAddress' => $OriginAddress,
            //         'DestinationAddress' => $DestinationAddress,
            //         'ShipmentDetails' => $ShipmentDetails,
            //         'PreferredCurrencyCode' => $baseCurrencyCode
            //     );
            //     if ($allowed_method == "CDA") {
            //         $params['ShipmentDetails']['Services'] = "";
            //     } else {
            //         $params['ShipmentDetails']['Services'] = "";
            //     }
            //     try {
            //         /*$price = "";*/
            //         $results = $soapClient->CalculateRate($params);
            //         $response = array();
            //         if ($results->HasErrors) {
            //             WC()->session->set('egyexpress_error', true);
            //             if (is_countable($results->Notifications->Notification) && count($results->Notifications->Notification) > 1) {
            //                 $error = "";
            //                 foreach ($results->Notifications->Notification as $notify_error) {
            //                     $error .= 'egyexpress: ' . $notify_error->Code . ' - ' . $notify_error->Message . "  *******  ";
            //                 }
            //                 $response['error'] = $error;
            //             } else {
            //                 if ($results->Notifications->Notification->Code == 'ERR20') {
            //                     continue;
            //                 }
            //                 if ($results->Notifications->Notification->Code == 'ERR61') {
            //                     continue;
            //                 }
            //                 $response['error'] = 'egyexpress: ' . $results->Notifications->Notification->Code . ' - ' . $results->Notifications->Notification->Message;
            //             }
            //             $response['type'] = 'error';
            //             $egyexpress_visit_checkout = WC()->session->get('egyexpress_visit_checkout');
            //             $egyexpress_set_first_success = WC()->session->get('egyexpress_set_first_success');
            //             $chosen_shipping_methods = WC()->session->get('chosen_shipping_methods');

            //             if (!$egyexpress_visit_checkout && !$egyexpress_set_first_success) {
            //                 $egyexpress_visit_checkout = 1;
            //             } else {
            //                 $egyexpress_visit_checkout = $egyexpress_visit_checkout + 1;
            //             }

            //             if ($egyexpress_visit_checkout === 1) {
            //                 $response['type'] = 'error_egyexpress';
            //                 WC()->session->set('egyexpress_visit_checkout', $egyexpress_visit_checkout);
            //             }
            //         } else {
            //             $egyexpress_visit_checkout = WC()->session->get('egyexpress_visit_checkout');
            //             if (!$egyexpress_visit_checkout) {
            //                 WC()->session->set('egyexpress_set_first_success', true);
            //             }
            //             WC()->session->set('egyexpress_error', false);
            //             $response['type'] = 'success';
            //             $price = $results->TotalAmount->Value;
            //             $curr_code = $results->TotalAmount->CurrencyCode;
            //         }
            //     } catch (Exception $e) {
            //         $response['type'] = 'error';
            //         $response['error'] = $e->getMessage();
            //     }

            //     if ($response['type'] == 'error_egyexpress') {
            //         $message = null;
            //         $messageType = "error";
            //         if (!wc_has_notice($message, $messageType)) {
            //             wc_add_notice($message, $messageType);
            //         }
            //     }
            //     if ($response['type'] == 'error') {
            //         $message = $response['error'];
            //         $messageType = "error";
            //         if (!wc_has_notice($message, $messageType)) {
            //             wc_add_notice($message, $messageType);
            //         }
            //     }

            //     if ($product_group == 'DOM') {
            //         foreach ($allowed_domestic_methods as $key_dom => $domestic_method) {
            //             if ($key_dom == $allowed_method) {
            //                 $title = $domestic_method;
            //                 break;
            //             }
            //         }
            //     } else {
            //         foreach ($allowed_international_methods as $key_int => $international_method) {
            //             if ($key_int == $allowed_method) {
            //                 $title = $international_method;
            //                 break;
            //             }
            //         }
            //     }
            //     if ($response['type'] == 'error') {
            //         $rate = array(
            //             'id' => $allowed_method . "_egyexpress",
            //             'label' => "egyexpress",
            //             'cost' => "",
            //             'meta_data' => [
            //                 'currency' => $curr_code
            //             ],
            //         );
            //         $this->add_rate($rate);
            //         break;
            //     }
            //     $title_without = $this->settings['hide_shipping_product1'];
            //     $title = $title ? "egyexpress " . $title : "";
            //     $price = empty($this->settings['egyexpress_round']) ? ceil( $price ) : $price;
            //     $rate = array(
            //         'id' => $allowed_method . "_egyexpress",
            //         'label' => empty(trim($title_without)) ? $title : $title_without,
            //         'cost' => $price,
            //         'meta_data' => [
            //             'currency' => $curr_code
            //         ],
            //     );
            //     $this->add_rate($rate);
            // }



        }

        /**
         *  Get total info about Admin
         *
         * @param string $nonce Nonce
         * @return array Total info
         */
        private function getInfo($nonce)
        {
            $baseUrl = $this->getWsdlPath($nonce);
            $clientInfo = $this->getClientInfo($nonce);

            return (array('baseUrl' => $baseUrl, 'clientInfo' => $clientInfo));
        }

        /**
         * Get info about Admin
         *
         * @param string $nonce Nonce
         * @return array
         */
        private function getClientInfo($nonce)
        {
            $settings = $this->getSettings($nonce);
            return array(
                'AccountCountryCode' => $settings['account_country_code'],
                'AccountEntity' => $settings['account_entity'],
                'AccountNumber' => $settings['account_number'],
                'AccountPin' => $settings['account_pin'],
                'UserName' => $settings['user_name'],
                'Password' => $settings['password'],
                'Version' => 'v1.0',
                'Source' => 52,
                'address' => $settings['address'],
                'city' => $settings['city'],
                'state' => $settings['state'],
                'postalcode' => $settings['postalcode'],
                'country' => $settings['country'],
                'name' => $settings['name'],
                'company' => $settings['company'],
                'phone' => $settings['phone'],
                'email' => $settings['email_origin'],
                'report_id' => $settings['report_id'],
            );
        }

        /**
         * Get path of WSDl file
         *
         * @return string
         */
        private function getPath()
        {
            return __DIR__ . '/../../wsdl/';
        }

        /**
         * Get Admin settings
         *
         * @param string $nonce Nonce
         * @return mixed|void
         */
        private function getSettings($nonce)
        {
            if (wp_verify_nonce($nonce, 'egyexpress-shipment-check' . wp_get_current_user()->user_email) == false) {
                echo(__('Invalid form data.'));
                die();
            }

            $includedStuff = get_included_files();
            $string = 'wp-config.php';
            $found = false;
            foreach ($includedStuff as $key => $url) {
                if (strpos($url, $string) !== false) {
                    $found = true;
                    break;
                }
            }
            if ($found == false) {
                require_once('../../../../../wp-config.php');
            }
            return get_option('woocommerce_egyexpress_settings');
        }

        /**
         * Get path of WSDL file
         *
         * @param string $nonce Nonce
         * @return string Path
         */
        private function getWsdlPath($nonce)
        {
            $settings = $this->getSettings($nonce);
            if ($settings['sandbox_flag'] == 1) {
                $path = $this->getPath() . 'test/';
            } else {
                $path = $this->getPath();
            }
            return $path;
        }
    }
}
