<?php
/*
Plugin Name:  egyexpress Shipping WooCommerce
Plugin URI:   https://egyexpress.com
Description:  egyexpress Shipping WooCommerce plugin
Version:      1.0.0
Author:       egyexpress.com
Author URI:   https://www.egyexpress.com/solutions-services/developers-solutions-center
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  egyexpress
Domain Path:  /languages
*/

if (!class_exists('egyexpress_Helper')) {

    /**
     * Class egyexpress_Helper is a helper
     */
    class egyexpress_Helper
    {
        /**
         * Path to WSDL file
         *
         * @var string Path to WSDL file
         */
        protected $wsdlBasePath;

        /**
         * Get path to WSDL file
         *
         * @return string Path to WSDL file
         */
        private function getPath()
        {
            return __DIR__ . '/../../wsdl/';
        }

        /**
         * Get Settings
         *
         * @param string $nonce Nonce
         * @return mixed|void Settings
         */
        private function getSettings($nonce)
        {
            if (wp_verify_nonce($nonce, 'egyexpress-shipment-check' . wp_get_current_user()->user_email) == false) {
                echo(__('Invalid form data.', 'egyexpress'));
                die();
            }

            $includedStuff = get_included_files();
            $string = 'wp-config.php';
            $found = false;
            foreach ($includedStuff as $key => $url) {
                if (strpos($url, $string) !== false) {
                    $found = true;
                    break;
                }
            }
            if ($found == false) {
                require_once('../../../../../wp-config.php');
            }
            return get_option('woocommerce_egyexpress_settings');
        }

        /**
         * Get Path to WSDL file
         *
         * @param string $nonce Nonce
         * @return string Path to Wsdl file
         */
        private function getWsdlPath($nonce)
        {
            $settings = $this->getSettings($nonce);
            if ($settings['sandbox_flag'] == 1) {
                $path = $this->getPath() . 'test/';
            } else {
                $path = $this->getPath();
            }
            return $path;
        }

        /**
         * Get admin`s settings
         *
         * @param string $nonce Nonce
         * @return array Admin settings
         */
        private function getClientInfo($nonce)
        {
            $settings = $this->getSettings($nonce);
            return array(
                'AccountCountryCode' => $settings['account_country_code'],
                'AccountEntity' => $settings['account_entity'],
                'AccountNumber' => $settings['account_number'],
                'AccountPin' => $settings['account_pin'],
                'UserName' => $settings['user_name'],
                'Password' => $settings['password'],
                'Version' => 'v1.0',
                'Source' => 52,
                'address' => $settings['address'],
                'city' => $settings['city'],
                'state' => $settings['state'],
                'postalcode' => $settings['postalcode'],
                'country' => $settings['country'],
                'name' => $settings['name'],
                'company' => $settings['company'],
                'phone' => $settings['phone'],
                'email' => $settings['email_origin'],
                'report_id' => $settings['report_id'],
                
            );
        }

        // public function getShipperStates(){
        //     return array (
        //     '1' =>'Abdeen',
        //     '2' => 'Abou Rawash',
        //     '3' => 'Abu an Numros',
        //     '4' =>'Agouza',
        //     '5' => 'Ain Shams',
        //     '6' =>  'Al Abageyah',
        //     '7' => 'Al Amiriyyah', 
        //     '8' =>  'Al Ayat', 
        //     '9' =>  'Al Badrashin',
        //     '10' => 'Al Baragel', 
        //     '11' =>  'Al Khusus', 
        //     '12' =>  'Al Manawat', 
        //     '13' =>  'Al Moatamadeyah', 
        //     '14' => 'Al Munib', 
        //     '15' => 'Al Salam', 
        //     '16' =>  'Al Sharabiya',
        //     '17' =>  'Ard El Lewa', 
        //     '18' =>  'Awal Shubra Al Kheimah', 
        //     '19' => 'Bab El-Shaeria', 
        //     '20' =>  'Basateen', 
        //     '21' =>  'Boulak', 
        //     '22' => 'Boulak Eldakrour',
        //     '23' => 'Agouza',
        //     '24' =>  'Dokki', 
        //     '25' =>  'El Azbakia', 
        //     '26' =>  'El Gamalia', 
        //     '27' =>  'El Hadba EL wosta',
        //     '28' =>  'El Hawamdeyya', 
        //     '29' =>  'El Marg', 
        //     '30' =>  'El Mosky', 
        //     '31' =>  'El Saf', 
        //     '32' =>  'El Talbia', 
        //     '33' =>  'El Waily', 
        //     '34' =>  'El Zaher', 
        //     '35' =>  'El Zawya El Hamra', 
        //     '36' =>  'ELdarb Elahmar', 
        //     '37' => 'Elsayeda Aisha', 
        //     '38' => 'Elsayeda Zeinab', 
        //     '39' => 'Eltebeen', 
        //     '40' => 'Future City',
        //     '41' => 'Hadayek Al Ahram',
        //     '42' => 'Hadayek El Qobah', 
        //     '43' => 'Haram', 
        //     '44' => 'Imbaba', 
        //     '45' => 'Izbat an Nakhl',
        //     '46' => 'Kafr Hakim', 
        //     '47' => 'Kafr Nassar', 
        //     '48' => 'Kafr Tuhurmis', 
        //     '49' => 'Manial', 
        //     '50' => 'Masr El Qadeema', 
        //     '51' => 'Mohandseen', 
        //     '52' => 'Nahia', 
        //     '53' => 'Nasr City', 
        //     '54' => 'Nazlet Al Batran', 
        //     '55' => 'Nazlet El Semman', 
        //     '56' => 'New Heliopolis City', 
        //     '57' => 'Nozha', 
        //     '58' => 'Omraneya', 
        //     '59' => 'Ossim', 
        //     '60' => 'Qalyubia', 
        //     '61' => 'Qasr elneil', 
        //     '62' => 'Rod El Farag',
        //     '63' => 'Saft El Laban', 
        //     '64' => 'Saqiyet Mekki', 
        //     '65' => 'Shoubra', 
        //     '66' => 'Shubra El Kheima 2', 
        //     '67' => 'Shubra Ment', 
        //     '68' => 'Tura', 
        //     '69' => 'Warraq', 
        //     '70' => 'Zamalek', 
        //     '71' => 'Zeitoun', 

        //     );
        // }

        // public function getStatesMap($id){
        //     $arrMap = array (
        //         "1" => "GAR",
        //         "2" => "OCT",
        //         "3" => "KAL",
        //         "4" => "MOH",
        //         "5" => "HEL",
        //         "6" => "MAD",
        //         "7" => "BEH",
        //         "8" => "KAL",
        //         "9" => "KAL",
        //         "10" => "MOH",
        //         "11" => "KAL",
        //         "12" => "KAL",
        //         "13" => "MOH",
        //         "14" => "MOH",
        //         "15" => "HEL",
        //         "16" => "GAR",
        //         "17" => "MOH",
        //         "18" => "KAL",
        //         "19" => "GAR",
        //         "20" => "MAD",
        //         "21" => "MOH",
        //         "22" => "MOH",
        //         "23" => "MOH",
        //         "24" => "MOH",
        //         "25" => "GAR",
        //         "26" => "GAR",
        //         "27" => "MAD",
        //         "28" => "KAL",
        //         "29" => "KAL",
        //         "30" => "GAR",
        //         "31" => "KAL",
        //         "32" => "MOH",
        //         "33" => "HEL",
        //         "34" => "GAR",
        //         "35" => "GAR",
        //         "36" => "GAR",
        //         "37" => "GAR",
        //         "38" => "GAR",
        //         "39" => "KAL",
        //         "40" => "RAM",
        //         "41" => "MOH",
        //         "42" => "HEL",
        //         "43" => "MOH",
        //         "44" => "MOH",
        //         "45" => "KAL",
        //         "46" => "MOH",
        //         "47" => "KAL",
        //         "48" => "KAL",
        //         "49" => "GAR",
        //         "50" => "GAR",
        //         "51" => "MOH",
        //         "52" => "MOH",
        //         "53" => "HEL",
        //         "54" => "MOH",
        //         "55" => "MOH",
        //         "56" => "RAM",
        //         "57" => "HEL",
        //         "58" => "MOH",
        //         "59" => "KAL",
        //         "60" => "KAL",
        //         "61" => "GAR",
        //         "62" => "MOH",
        //         "63" => "MOH",
        //         "64" => "MOH",
        //         "65" => "GAR",
        //         "66" => "KAL",
        //         "67" => "KAL",
        //         "68" => "MAD",
        //         "69" => "MOH",
        //         "70" => "MOH",
        //         "71" => "HEL",

        //     );

        //     return $arrMap[$id];
        // }

        public function Mylrez(){
            $cities = [
                
                "10th of Ramadan",
                "15th of May",
                "6th of Oct",
                "Abbaseya",
                "Abdeen",
                "Abou Rawash",
                "Abu an Numros",
                "Agouza",
                "Ain Shams",
                "Al Abageyah",
                "Al Amiriyyah",
                "Al Ayat",
                "Al Badrashin",
                "Al Baragel",
                "Al Khusus",
                "Al Manawat",
                "Al Moatamadeyah",
                "Al Munib",
                "Al Salam",
                "Al Sharabiya",
                "Alexandria",
                "Ard El Lewa",
                "Aswan",
                "Asyut",
                "Awal Shubra Al Kheimah",
                "Bab El-Shaeria",
                "Badr City",
                "Basateen",
                "Beheira",
                "Beni Suef",
                "Boulak",
                "Boulak Eldakrour",
                "CFC",
                "Dakahlia",
                "Damietta",
                "Dokki",
                "El Azbakia",
                "El Gamalia",
                "El Giza",
                "El Hadba EL wosta",
                "El Hawamdeyya",
                "El Marg",
                "El Mosky",
                "El Obour City",
                "El Saf",
                "El Shorouk",
                "El Talbia",
                "El Waily",
                "El Zaher",
                "El Zawya El Hamra",
                "ELdarb Elahmar",
                "Elsayeda Aisha",
                "Elsayeda Zeinab",
                "Eltebeen",
                "Faiyum",
                "Future City",
                "Ghamra",
                "Gharbia",
                "Hadayek Al Ahram",
                "Hadayek El Qobah",
                "Haram",
                "Heliopolis",
                "Helwan",
                "Imbaba",
                "Ismailia",
                "Izbat an Nakhl",
                "Kafr El Sheikh",
                "Kafr Hakim",
                "Kafr Nassar",
                "Kafr Tuhurmis",
                "Luxor",
                "Maadi",
                "Madinaty",
                "Manial",
                "Masr El Qadeema",
                "Minya",
                "Mohandseen",
                "Monufia",
                "Nahia",
                "Nasr City",
                "Nazlet Al Batran",
                "Nazlet El Semman",
                "New Cairo",
                "New Heliopolis City",
                "North Coast",
                "Nozha",
                "Omraneya",
                "Ossim",
                "Port Said",
                "Qalyubia",
                "Qasr elneil",
                "Qena",
                "Rod El Farag",
                "Saft El Laban",
                "Saqiyet Mekki",
                "Sharqia",
                "Sheikh Zayed",
                "Shoubra",
                "Shubra El Kheima 2",
                "Shubra Ment",
                "Sohag",
                "Suez",
                "Tura",
                "Warraq",
                "Zamalek",
                "Zeitoun",
            ];
            
            $zones = [
                
                "RMDN",
                "15th of May",
                "6th of Oct",
                "ABAS",
                "Abdeen",
                "RWSH",
                "NMRS",
                "Agouza",
                "AS",
                "ABAG",
                "AMRY",
                "AYAT",
                "BDRA",
                "BRAG",
                "KHSU",
                "MNWT",
                "MOTM",
                "MUNB",
                "Al-S",
                "SHRB",
                "Alexandria",
                "LWAA",
                "ASWN",
                "ASYT",
                "KHM1",
                "Bab El-Shaeria",
                "Badr City",
                "Basateen",
                "BEHR",
                "BENS",
                "Boulak",
                "Boulak Eldakrour",
                "CFC",
                "DAKH",
                "DAMT",
                "Dokki",
                "El-Azbakia",
                "El-Gamalia",
                "GIZA",
                "HDBA",
                "HWMD",
                "El-M",
                "El-Mosky",
                "OBOR",
                "SAF",
                "El Shorouk",
                "TLBA",
                "El-Waily",
                "ZAHR",
                "ZWYA",
                "ELdarb Elahmar",
                "ESHA",
                "Elsayeda Zeinab",
                "Eltebeen",
                "FAYM",
                "FUTR",
                "GHMR",
                "GHRB",
                "Hadayek Al Ahram",
                "Hadayek El Qobah",
                "Haram",
                "HEl",
                "Helwan",
                "Imbaba",
                "ISML",
                "NKHL",
                "SHKH",
                "KFRH",
                "NASR",
                "TRMS",
                "LUXR",
                "Maadi",
                "Madinaty",
                "Manial",
                "Masr El Qadeema",
                "MNYA",
                "Mohandseen",
                "MONF",
                "Nahia",
                "Nasr City",
                "BTRN",
                "SMAN",
                "New Cairo",
                "NHEL",
                "NorthCoast",
                "Nozha",
                "Omraneya",
                "OSIM",
                "PORS",
                "QLYB",
                "Qasr elneil",
                "QENA",
                "FRAG",
                "Saft El Laban",
                "MEKI",
                "SHRK",
                "Sheikh Zayed",
                "Shoubra",
                "KHM2",
                "MANT",
                "SOHG",
                "SUEZ",
                "TURA",
                "Warraq",
                "Zamalek",
                "Zeitoun",
            ];

           return $zones_cities = array_combine($zones, $cities);
        }

        public function mylrezState_to_fedexCode(){

            return array(

              "Abdeen" =>	"GAR",
              "Abou Rawash" =>	"OCT",
              "Abu an Numros" =>	"KAL",
              "Agouza" =>	"MOH",
              "Ain Shams" =>	"HEL",
              "Al Abageyah" =>	"MAD",
              "Al Amiriyyah" =>	"BEH",
              "Al Ayat" =>	"KAL",
              "Al Badrashin" =>	"KAL",
              "Al Baragel" =>	"MOH",
              "Al Khusus" =>	"KAL",
              "Al Manawat" =>	"KAL",
              "Al Moatamadeyah" =>	"MOH",
              "Al Munib" =>	"MOH",
              "Al Salam" =>	"HEL",
              "Al Sharabiya" =>	"GAR",
              "Ard El Lewa" =>	"MOH",
              "Awal Shubra Al Kheimah" =>	"KAL",
              "Bab El-Shaeria" => 	"GAR",
              "Basateen" =>	"MAD",
              "Boulak" =>	"MOH",
              "Boulak Eldakrour" =>	"MOH",
              "Dokki" =>	"MOH",
              "El Azbakia" =>	"GAR",
              "El Gamalia" =>	"GAR",
              "El Hadba EL wosta" =>	"MAD",
              "El Hawamdeyya" =>	"KAL",
              "El Marg" =>	"KAL",
              "El Mosky" =>  	"GAR",
              "El Saf" =>	"KAL",
              "El Talbia" =>	"MOH",
              "El Waily" =>	"HEL",
              "El Zaher" =>	"GAR",
              "El Zawya El Hamra" =>	"GAR",
              "ELdarb Elahmar" =>	"GAR",
              "Elsayeda Aisha" =>	"GAR",
              "Elsayeda Zeinab" =>	"GAR",
              "Eltebeen" =>	"KAL",
              "Future City" =>	"RAM",
              "Hadayek Al Ahram" =>	"MOH",
              "Hadayek El Qobah" =>	"HEL",
              "Haram" =>	"MOH",
              "Imbaba" =>	"MOH",
              "Izbat an Nakhl" =>	"KAL",
              "Kafr Hakim" =>	"MOH",
              "Kafr Nassar" =>	"KAL",
              "Kafr Tuhurmis" =>	"KAL",
              "Manial" =>	"GAR",
              "Masr El Qadeema" =>	"GAR",
              "Mohandseen"  =>	"MOH",
              "Nahia" =>	"MOH",
              "Nasr City" =>	"HEL",
              "Nazlet Al Batran" =>	"MOH",
              "Nazlet El Semman" =>	"MOH",
              "New Heliopolis City" =>	"RAM",
              "Nozha" =>	"HEL",
              "Omraneya" =>	"MOH",
              "Ossim" =>   	"KAL",
              "Qasr elneil" =>  	"GAR",
              "Rod El Farag" =>	"MOH",
              "Saft El Laban" =>	"MOH",
              "Saqiyet Mekki" =>	"MOH",
              "Shoubra" =>	"GAR",
              "Shubra El Kheima 2" =>	"KAL",
              "Shubra Ment" =>	"KAL",
              "Tura" =>	"MAD",
              "Warraq" =>	"MOH",
              "Zamalek" =>	"MOH",
              "Zeitoun" =>	"HEL",
              "10th of Ramadan"  => 'RAM',
              "15th of May" =>  'MAY',
              "6th of Oct" =>  'OCT',
              "Abbaseya" => 'CAI',
              "Alexandria" => 'ALX',
              "Aswan" =>  'ASW ',
              "Asyut" => 'ASU',
              "Badr City" => 'BAD',
              "Beheira" => 'BEH',
              "Beni Suef" => 'BNS',
              "Dakahlia" => 'DAK',
              "Damietta" => 'QDX',
              "El Giza" => 'GIZ',
              "El Obour City" => 'OBR',
              "El Shorouk" => 'SHO',
              "Faiyum" => 'FAY',
              "Heliopolis" => 'HEL',
              "Helwan" => 'HLW',
              "Ismailia" => 'QIV',
              "Kafr El Sheikh" => 'KAZ',
              "Luxor" => 'LXR',
              "Maadi" => 'MAD',
              "Madinaty" => 'MNT',
              "Minya" => 'EMY',
              "Monufia" =>'MEN',
              "New Cairo" =>'NCO',
              "North Coast" => 'NOC',
              "Port Said" => 'PSD',
              "Qalyubia" => 'KAL',
              "Qena" => 'QNA',
              "Sharqia" => 'QZZ',
              "Sheikh Zayed" => 'SHZ',
              "Sohag" => 'QHX',
              "Suez" => 'SUZ',
              "Ghamra" => 'CAI'
          );
          
        }

        public function mapping_mylrezCode_to_fedexCode($mylrezCode){
            $mylrez = $this->Mylrez();
            $mylrezState =  $mylrez[$mylrezCode];//array_search ($mylrezCode, $mylrez);
            return $fedexcode = $this->mylrezState_to_fedexCode()[$mylrezState];
        }

        /**
         * Get admin`s COD settings
         *
         * @param string $nonce Nonce
         * @return array Admin`s COD settings
         */
        private function getClientInfoCOD($nonce)
        {
            $settings = $this->getSettings($nonce);
            return array(
                'AccountCountryCode' => $settings['cod_account_country_code'],
                'AccountEntity' => $settings['cod_account_entity'],
                'AccountNumber' => $settings['cod_account_number'],
                'AccountPin' => $settings['cod_account_pin'],
                'UserName' => $settings['user_name'],
                'Password' => $settings['password'],
                'Version' => 'v1.0',
                'Source' => 52,
                'address' => $settings['address'],
                'city' => $settings['city'],
                'state' => $settings['state'],
                'postalcode' => $settings['postalcode'],
                'country' => $settings['country'],
                'name' => $settings['name'],
                'company' => $settings['company'],
                'phone' => $settings['phone'],
                'email' => $settings['email_origin'],
                'report_id' => $settings['report_id'],

            );
        }

        /**
         * Get admin`s Email settings
         *
         * @param string $nonce Nonce
         * @return array Admin`s Email settings
         */
        private function getEmailOptions($nonce)
        {
            $settings = $this->getSettings($nonce);
            return array(
                'copy_to' => $settings['copy_to'],
                'copy_method' => $settings['copy_method'],
            );
        }

        /**
         * Format input data
         *
         * @param $array Input data
         * @return array Result of formatting
         */
        protected function formatPost($array)
        {
            $out = array();
            foreach ($array as $key => $val) {
                if (is_array($val)) {
                    foreach ($val as $key1 => $val1) {
                        if (!is_array($val1)) {
                            if ($val1 != "") {
                                $out[$key][$key1] = htmlspecialchars(strip_tags(trim(sanitize_text_field($val1))));
                            } else {
                                $out[$key][$key1] = "";
                            }
                        }
                    }
                } else {
                    $out[$key] = htmlspecialchars(strip_tags(trim(sanitize_text_field($val))));
                }
            }
            return $out;
        }

        /**
         * Get info about Admin
         *
         * @param $nonce Nonce
         * @return array Admin info
         */
        protected function getInfo($nonce)
        {
            $baseUrl = $this->getWsdlPath($nonce);
            $clientInfo = $this->getClientInfo($nonce);
            $copyInfo = $this->getEmailOptions($nonce);
            return (array('baseUrl' => $baseUrl, 'clientInfo' => $clientInfo, '$copyInfo' => $copyInfo));
        }

        /**
         * Get info about Admin (COD)
         *
         * @param $nonce Nonce
         * @return array Admin info
         */
        protected function getInfoCod($nonce)
        {
            $baseUrl = $this->getWsdlPath($nonce);
            $clientInfo = $this->getClientInfoCOD($nonce);
            $copyInfo = $this->getEmailOptions($nonce);
            return (array('baseUrl' => $baseUrl, 'clientInfo' => $clientInfo, '$copyInfo' => $copyInfo));
        }
    }
}
