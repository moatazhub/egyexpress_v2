/*
Plugin Name:  egyexpress Shipping WooCommerce
Plugin URI:   https://egyexpress.com
Description:  egyexpress Shipping WooCommerce plugin
Version:      1.0.0
Author:       egyexpress.com
Author URI:   https://www.egyexpress.com/solutions-services/developers-solutions-center
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  egyexpress
Domain Path:  /languages
 */

jQuery.noConflict();
(function ($) {
  jQuery(document).ready(function ($) {
    // $( "#egyexpress_overlay" ).insertBefore( $(  "#post" ));
    $('#create_egyexpress_shipment').insertBefore($('#order_data'));
    $('#create_egyexpress_shipment').css('display', 'inline-block');
    $('#track_egyexpress_shipment').insertBefore($('#order_data'));
    $('#track_egyexpress_shipment').css('display', 'inline-block');
    $('#print_egyexpress_shipment').insertBefore($('#order_data'));
    $('#print_egyexpress_shipment').css('display', 'inline-block');

    function egyexpresspop() {
      $('#egyexpress_overlay').css('display', 'block');
      $('#egyexpress_shipment').css('display', 'block');
      $('#egyexpress_shipment_creation').fadeIn(1000);
    }

    $('#create_egyexpress_shipment').click(function () {
      egyexpresspop();
    });
    $('#egyexpress_close').click(function () {
      egyexpress_close();
    });
  });

  function egyexpress_close() {
    $('#egyexpress_shipment').css('display', 'none');
    $('#egyexpress_overlay').css('display', 'none');
  }
})(jQuery);
