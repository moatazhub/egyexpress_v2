<?php
/*
Plugin Name:  egyexpress Shipping WooCommerce
Plugin URI:   https://egyexpress.com
Description:  egyexpress Shipping WooCommerce plugin
Version:      1.0.0
Author:       egyexpress.com
Author URI:   https://www.egyexpress.com/solutions-services/developers-solutions-center
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  egyexpress
Domain Path:  /languages
*/
?>
<?php
        /**
         *  Render "Print label" form
         *
         * @param $order object Order object
         * @return string Template
         */
function egyexpress_display_printlabel_in_admin($order)
{
    $get_userdata = get_userdata(get_current_user_id());
    // if (!$get_userdata->allcaps['edit_shop_order'] || !$get_userdata->allcaps['read_shop_order'] || !$get_userdata->allcaps['edit_shop_orders'] || !$get_userdata->allcaps['edit_others_shop_orders']
    //     || !$get_userdata->allcaps['publish_shop_orders'] || !$get_userdata->allcaps['read_private_shop_orders']
    //     || !$get_userdata->allcaps['edit_private_shop_orders'] || !$get_userdata->allcaps['edit_published_shop_orders']) {
    //     return false;
    // }
    $order_id = $order->get_id();
    $currentUrl = home_url(add_query_arg(null, null));
    $history = get_comments(array(
        'post_id' => $order_id,
        'orderby' => 'comment_ID',
        'order' => 'DESC',
        'approve' => 'approve',
        'type' => 'order_note',
    ));

    $history_list = array();
    foreach ($history as $shipment) {
        $history_list[] = $shipment->comment_content;
    }
    $last_track = "";
    if (count($history_list)) {
        foreach ($history_list as $history) {
            $awbno = strstr($history, "- Order No", true);
            $awbno = trim($awbno, "AWB No.");
            if (isset($awbno)) {
                if ((int)$awbno) {
                    $last_track = $awbno;
                    break;
                }
            }
            $awbno = trim($awbno, "egyexpress Shipment Return Order AWB No.");
            if (isset($awbno)) {
                if ((int)$awbno) {
                    $last_track = $awbno;
                    break;
                }
            }
        }
    } ?>
    <?php
    if (isset($_SESSION['egyexpress_errors_printlabel'])) {
        unset($_SESSION['egyexpress_errors_printlabel']);
    } ?>
    <div id="printlabel_overlay" style="display:none;">
        <form method="post"
              action=" <?php echo esc_url(plugins_url() . '/egyexpress-shipping-woocommerce/includes/shipment/class-egyexpress-woocommerce-printlabel.php'); ?>"
              id="printlabel-form">
            <input name="_wpnonce" id="egyexpress-shipment-nonce" type="hidden"
                   value="<?php echo esc_attr(wp_create_nonce('egyexpress-shipment-check' . wp_get_current_user()->user_email)); ?>"/>
            <input type="hidden" name="egyexpress_shipment_referer" value="<?php echo esc_attr(esc_url($currentUrl)); ?>"/>
            <input name="egyexpress-printlabel" id="egyexpress-printlabel-field" type="hidden"
                   value="<?php echo esc_attr($order_id); ?>"/>
            <input name="egyexpress-lasttrack" id="egyexpress-lasttrack-field" type="hidden"
                   value="<?php echo esc_attr($last_track); ?>"/>

        </form>
    </div>
<?php 
}
