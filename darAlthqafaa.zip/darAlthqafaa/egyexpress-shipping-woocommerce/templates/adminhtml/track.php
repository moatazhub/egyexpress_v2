<?php
/*
Plugin Name:  egyexpress Shipping WooCommerce
Plugin URI:   https://egyexpress.com
Description:  egyexpress Shipping WooCommerce plugin
Version:      1.0.0
Author:       egyexpress.com
Author URI:   https://www.egyexpress.com/solutions-services/developers-solutions-center
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  egyexpress
Domain Path:  /languages
*/
?>
<?php
        /**
         *  Render "Traching" form
         *
         * @param $order object Order object
         * @return string Template
         */
function egyexpress_display_track_in_admin($order)
{
    $get_userdata = get_userdata(get_current_user_id());
    // if (!$get_userdata->allcaps['edit_shop_order'] || !$get_userdata->allcaps['read_shop_order'] || !$get_userdata->allcaps['edit_shop_orders'] || !$get_userdata->allcaps['edit_others_shop_orders']
    //     || !$get_userdata->allcaps['publish_shop_orders'] || !$get_userdata->allcaps['read_private_shop_orders']
    //     || !$get_userdata->allcaps['edit_private_shop_orders'] || !$get_userdata->allcaps['edit_published_shop_orders']) {
    //     return false;
    // }
    global $post;
    $order = new WC_Order($post->ID);
    $order_id = $order->get_id();
    $history = get_comments(array(
        'post_id' => $order_id,
        'orderby' => 'comment_ID',
        'order' => 'DESC',
        'approve' => 'approve',
        'type' => 'order_note',
    ));

    $history_list = array();
    foreach ($history as $shipment) {
        $history_list[] = $shipment->comment_content;
    }
    $last_track = "";
    if (count($history_list)) {
        foreach ($history_list as $history) {
            $awbno = strstr($history, "- Order No", true);
            $awbno = trim($awbno, "AWB No.");

            if (isset($awbno)) {
                if ((int)$awbno) {
                    $last_track = $awbno;
                    break;
                }
            }
            $awbno = trim($awbno, "egyexpress Shipment Return Order AWB No.");
            if (isset($awbno)) {
                if ((int)$awbno) {
                    $last_track = $awbno;
                    break;
                }
            }
        }
    } ?>
    <!-- egyexpress Tracking -->
    <div id="track_overlay" style="display:none;">
        <div class="track-form" style="display:none;">
            <form method="post" action="" id="track-form">
                <input name="egyexpress-shipment-nonce" id="egyexpress-shipment-nonce" type="hidden"
                       value="<?php echo esc_attr(wp_create_nonce('egyexpress-shipment-nonce')); ?>"/>
                <FIELDSET>
                    <legend style="font-weight:bold; padding:0 5px;"><?php echo esc_html__('Track egyexpress Shipment',
                            'egyexpress'); ?></legend>
                    <input name="_wpnonce" id="egyexpress-shipment-nonce" type="hidden"
                           value="<?php echo esc_attr(wp_create_nonce('egyexpress-shipment-check' . wp_get_current_user()->user_email)); ?>"/>
                    <?php if ($last_track != "") {
                                ?>
                        <input name="egyexpress-track" id="egyexpress-track-field"
                               value="<?php echo esc_attr($last_track); ?>"/>
                    <?php 
                            } else {
                                ?>
                        <p><?php echo esc_html__('egyexpress shipment was not created', 'egyexpress'); ?></p>
                    <?php 
                            } ?>
                </FIELDSET>
                <div class="egyexpress_loader"
                     style="background-image: url(<?php echo esc_js(esc_url(plugins_url() . '/egyexpress-shipping-woocommerce/assets/img/preloader.gif')); ?>); height:60px; margin:10px 0; background-position-x: center; display:none; background-repeat: no-repeat; ">
                </div>
                <div class="track-result mar-10" style="display:none;">
                    <h3><?php echo esc_html__('Result', 'egyexpress'); ?></h3>
                    <div class="result mar-10"></div>
                </div>
                <button id="egyexpress_track_submit_id" type="button" name="egyexpress_track_submit" class="button-primary">
                    <?php echo esc_html__('Track Shipment', 'egyexpress'); ?>
                </button>
                <button id="track_close" class="button-primary" type="button"><?php echo esc_html__('Close',
                        'egyexpress'); ?></button>
                <script type="text/javascript">
                    jQuery.noConflict();
                    (function ($) {
                        $(document).ready(function () {
                            $('#track_egyexpress_shipment').click(function () {
                                $('.track-result').css("display", "none");
                                $('#track_overlay').css("display", "block");
                                $('.track-form').css("display", "block");
                            });
                            $('#egyexpress_track_submit_id').click(function () {
                                myObj.track();
                            });
                            $('#track_close').click(function () {
                                $('#track_overlay').css("display", "none");
                            });
                        });
                    })(jQuery);
                </script>
            </form>
        </div>
    </div>
<?php 
} ?>